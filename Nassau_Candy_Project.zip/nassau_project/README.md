# Nassau Candy Distributor - Product Line Profitability & Margin Performance

End-to-end analytics project: data cleaning, KPI engine, Streamlit dashboard, formula-driven Excel model,
Tableau-ready data + build guide, research paper and executive summary.

## Folder map
| Path | What it is |
|---|---|
| `app.py` | Streamlit dashboard (5 tabs, 4 filters, repricing simulator) |
| `analysis.py` | Single source of truth for cleaning, KPIs, segmentation, Pareto |
| `Nassau_Candy_Profitability_Analysis.xlsx` | Excel workbook - 795 live formulas, 9 sheets, charts |
| `tableau/` | 9 Tableau-ready CSVs + `TABLEAU_GUIDE.md` (fields, sheets, dashboards) |
| `docs/` | Research paper and executive summary (.docx) |
| `charts/` | PNG figures used in the paper |
| `build_assets.py`, `build_excel.py`, `build_docs.py` | Re-generate every artefact from the CSV |
| `data/Nassau_Candy_Distributor.csv` | Source data (10,194 order lines) |

## Run the dashboard
```bash
pip install -r requirements.txt
streamlit run app.py
```
Deploy free on Streamlit Community Cloud: push this folder to GitHub, choose `app.py` as the entry point.

## Regenerate outputs
```bash
python build_assets.py   # charts + Tableau CSVs + key_numbers.json
python build_excel.py    # Excel workbook
python build_docs.py     # paper + executive summary
```

## Headline results
Sales $141.8K, gross profit $93.4K, gross margin 65.9%. Five Wonka Bars deliver 95% of profit. Kazookles earns only
7.7% margin. Division "Other" runs at 44.8% vs 67.4% for Chocolate.
