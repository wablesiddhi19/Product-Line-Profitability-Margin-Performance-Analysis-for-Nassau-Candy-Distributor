"""
Nassau Candy Distributor - Product Line Profitability & Margin Performance
Core analytics module shared by the Streamlit app, the Excel/Tableau export
and the report builder, so every deliverable uses one set of definitions.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

DATA_PATH = Path(__file__).parent / "data" / "Nassau_Candy_Distributor.csv"

# Product -> factory mapping supplied in the project brief
FACTORY_MAP = {
    "Wonka Bar - Nutty Crunch Surprise": "Lot's O' Nuts",
    "Wonka Bar - Fudge Mallows": "Lot's O' Nuts",
    "Wonka Bar - Scrumdiddlyumptious": "Lot's O' Nuts",
    "Wonka Bar - Milk Chocolate": "Wicked Choccy's",
    "Wonka Bar - Triple Dazzle Caramel": "Wicked Choccy's",
    "Laffy Taffy": "Sugar Shack",
    "SweeTARTS": "Sugar Shack",
    "Nerds": "Sugar Shack",
    "Fun Dip": "Sugar Shack",
    "Fizzy Lifting Drinks": "Sugar Shack",
    "Everlasting Gobstopper": "Secret Factory",
    "Hair Toffee": "The Other Factory",
    "Lickable Wallpaper": "Secret Factory",
    "Wonka Gum": "Secret Factory",
    "Kazookles": "The Other Factory",
}
FACTORY_COORDS = {
    "Lot's O' Nuts": (32.881893, -111.768036),
    "Wicked Choccy's": (32.076176, -81.088371),
    "Sugar Shack": (48.11914, -96.18115),
    "Secret Factory": (41.446333, -90.565487),
    "The Other Factory": (35.1175, -89.971107),
}

# Risk-flag cut-offs (gross margin, %)
CRITICAL_GM = 25.0     # below this -> reprice + discontinuation review
RENEGOTIATE_GM = 50.0  # below this -> cost renegotiation


def _clean_label(s: pd.Series) -> pd.Series:
    s = s.astype(str).str.strip().str.replace(r"\s+", " ", regex=True)
    # standardise e.g. "Wonka Bar -Scrumdiddlyumptious" -> "Wonka Bar - Scrumdiddlyumptious"
    return s.str.replace(r"\s*-\s*", " - ", regex=True)


def load_raw(path: Path | str = DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(path)


def clean(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Validate and clean; returns (clean_df, audit_log)."""
    log = {"rows_in": len(df)}
    df = df.copy()
    for c in ["Product Name", "Division", "Region", "State/Province", "City", "Ship Mode"]:
        df[c] = df[c].astype(str).str.strip().str.replace(r"\s+", " ", regex=True)
    df["Product Name"] = _clean_label(df["Product Name"])
    df["Division"] = df["Division"].str.title()

    df["Order Date"] = pd.to_datetime(df["Order Date"], dayfirst=True, errors="coerce")
    df["Ship Date"] = pd.to_datetime(df["Ship Date"], dayfirst=True, errors="coerce")
    log["bad_order_dates"] = int(df["Order Date"].isna().sum())

    for c in ["Sales", "Units", "Gross Profit", "Cost"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    log["missing_units"] = int(df["Units"].isna().sum())
    # impute missing units from the product's median unit price (none missing in this file)
    unit_price = (df["Sales"] / df["Units"]).groupby(df["Product Name"]).transform("median")
    df["Units"] = df["Units"].fillna((df["Sales"] / unit_price).round())

    bad = (
        df["Sales"].isna() | (df["Sales"] <= 0) | df["Cost"].isna() | (df["Cost"] < 0)
        | df["Gross Profit"].isna() | df["Units"].isna() | (df["Units"] <= 0)
    )
    log["invalid_removed"] = int(bad.sum())
    df = df[~bad & df["Order Date"].notna()].copy()

    # reconcile: Gross Profit must equal Sales - Cost
    mismatch = (df["Sales"] - df["Cost"] - df["Gross Profit"]).abs() > 0.02
    log["profit_mismatch"] = int(mismatch.sum())
    df.loc[mismatch, "Gross Profit"] = df["Sales"] - df["Cost"]

    log["exact_duplicates"] = int(df.duplicated().sum())
    df = df.drop_duplicates()

    df["Factory"] = df["Product Name"].map(FACTORY_MAP)
    df["Month"] = df["Order Date"].dt.to_period("M").dt.to_timestamp()
    df["Year"] = df["Order Date"].dt.year
    df["Gross Margin %"] = df["Gross Profit"] / df["Sales"] * 100
    log["rows_out"] = len(df)
    log["ship_lag_days_median"] = int((df["Ship Date"] - df["Order Date"]).dt.days.median())
    return df.reset_index(drop=True), log


def load_clean() -> tuple[pd.DataFrame, dict]:
    return clean(load_raw())


# ---------------------------------------------------------------- metrics
def _agg(df: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    g = (df.groupby(by, observed=True)
           .agg(Sales=("Sales", "sum"), Cost=("Cost", "sum"),
                GP=("Gross Profit", "sum"), Units=("Units", "sum"),
                Lines=("Row ID", "count"))
           .reset_index()
           .rename(columns={"GP": "Gross Profit", "Lines": "Order Lines"}))
    g["Gross Margin %"] = np.where(g["Sales"] > 0, g["Gross Profit"] / g["Sales"] * 100, 0)
    g["Profit per Unit"] = np.where(g["Units"] > 0, g["Gross Profit"] / g["Units"], 0)
    g["Avg Price per Unit"] = np.where(g["Units"] > 0, g["Sales"] / g["Units"], 0)
    g["Cost per Unit"] = np.where(g["Units"] > 0, g["Cost"] / g["Units"], 0)
    g["Cost Ratio %"] = np.where(g["Sales"] > 0, g["Cost"] / g["Sales"] * 100, 0)
    return g


def margin_volatility(df: pd.DataFrame, by: str) -> pd.Series:
    """Std-dev (percentage points) of monthly gross margin per `by` group."""
    m = _agg(df, [by, "Month"])
    return m.groupby(by)["Gross Margin %"].std().fillna(0)


def segment(rev_share, gm, thr, avg_share):
    hi_sales, hi_margin = rev_share >= avg_share, gm >= thr
    if hi_sales and hi_margin:
        return "Star"
    if hi_sales:
        return "Volume trap"
    if hi_margin:
        return "Niche premium"
    return "Under-performer"


def risk_flag(gm, thr):
    if gm < CRITICAL_GM:
        return "Critical"
    if gm < RENEGOTIATE_GM:
        return "High"
    if gm < thr:
        return "Watch"
    return "Healthy"


def action(gm, rev_share, thr, avg_share):
    if gm < CRITICAL_GM:
        return "Reprice + renegotiate cost; discontinuation review if no uplift"
    if gm < RENEGOTIATE_GM:
        return "Cost renegotiation / modest price increase"
    if gm < thr:
        return "Monitor; test small price or sourcing improvement"
    return "Protect and grow" if rev_share >= avg_share else "Maintain; cross-sell"


def product_metrics(df: pd.DataFrame, margin_threshold: float | None = None) -> pd.DataFrame:
    p = _agg(df, ["Division", "Product Name", "Factory"])
    tot_s, tot_p = p["Sales"].sum(), p["Gross Profit"].sum()
    p["Revenue Contribution %"] = p["Sales"] / tot_s * 100 if tot_s else 0.0
    p["Profit Contribution %"] = p["Gross Profit"] / tot_p * 100 if tot_p else 0.0
    p["Margin Volatility (pp)"] = p["Product Name"].map(margin_volatility(df, "Product Name")).fillna(0)
    overall = tot_p / tot_s * 100 if tot_s else 0.0
    thr = overall if margin_threshold is None else margin_threshold
    p["Rank by Profit"] = p["Gross Profit"].rank(ascending=False, method="min").astype(int)
    p["Rank by Margin"] = p["Gross Margin %"].rank(ascending=False, method="min").astype(int)
    avg_share = 100 / max(len(p), 1)
    p["Segment"] = [segment(s, m, thr, avg_share) for s, m in zip(p["Revenue Contribution %"], p["Gross Margin %"])]
    p["Risk Flag"] = [risk_flag(m, thr) for m in p["Gross Margin %"]]
    p["Recommended Action"] = [action(m, s, thr, avg_share) for m, s in zip(p["Gross Margin %"], p["Revenue Contribution %"])]
    return p.sort_values("Gross Profit", ascending=False).reset_index(drop=True)


def division_metrics(df: pd.DataFrame) -> pd.DataFrame:
    d = _agg(df, ["Division"])
    d["Revenue Share %"] = d["Sales"] / d["Sales"].sum() * 100
    d["Profit Share %"] = d["Gross Profit"] / d["Gross Profit"].sum() * 100
    d["Profit - Revenue Gap (pp)"] = d["Profit Share %"] - d["Revenue Share %"]
    pm = _agg(df, ["Division", "Product Name"])
    d["Avg Product Margin % (simple)"] = d["Division"].map(pm.groupby("Division")["Gross Margin %"].mean())
    d["Margin Volatility (pp)"] = d["Division"].map(margin_volatility(df, "Division")).fillna(0)
    d["Products"] = d["Division"].map(df.groupby("Division")["Product Name"].nunique())
    return d.sort_values("Gross Profit", ascending=False).reset_index(drop=True)


def factory_metrics(df: pd.DataFrame) -> pd.DataFrame:
    f = _agg(df, ["Factory"])
    f["Lat"] = f["Factory"].map(lambda x: FACTORY_COORDS[x][0])
    f["Lon"] = f["Factory"].map(lambda x: FACTORY_COORDS[x][1])
    return f.sort_values("Gross Profit", ascending=False).reset_index(drop=True)


def monthly_trend(df: pd.DataFrame, by: str | None = None) -> pd.DataFrame:
    return _agg(df, [by, "Month"] if by else ["Month"])


def region_metrics(df: pd.DataFrame, by: str = "Region") -> pd.DataFrame:
    r = _agg(df, [by])
    r["Profit Share %"] = r["Gross Profit"] / r["Gross Profit"].sum() * 100
    return r.sort_values("Gross Profit", ascending=False).reset_index(drop=True)


# ---------------------------------------------------------------- pareto
def pareto(df: pd.DataFrame, by: str = "Product Name", measure: str = "Gross Profit") -> pd.DataFrame:
    g = df.groupby(by)[measure].sum().sort_values(ascending=False).reset_index()
    g["Share %"] = g[measure] / g[measure].sum() * 100
    g["Cumulative %"] = g["Share %"].cumsum()
    g["Rank"] = np.arange(1, len(g) + 1)
    g["Item %"] = g["Rank"] / len(g) * 100
    return g


def n_to_reach(par: pd.DataFrame, target: float = 80.0) -> int:
    return int((par["Cumulative %"] < target - 1e-9).sum() + 1)


def concentration_summary(df: pd.DataFrame) -> dict:
    ps, pp = pareto(df, measure="Sales"), pareto(df, measure="Gross Profit")
    n = df["Product Name"].nunique()
    out = {
        "n_products": n,
        "n80_rev": n_to_reach(ps), "n80_profit": n_to_reach(pp),
        "top1_profit_share": float(pp["Share %"].iloc[0]),
        "top3_profit_share": float(pp["Share %"].head(3).sum()),
        "top5_profit_share": float(pp["Share %"].head(5).sum()),
        "hhi_profit": float((pp["Share %"] ** 2).sum()),  # 0-10,000 scale
    }
    out["pct80_rev"] = out["n80_rev"] / n * 100
    out["pct80_profit"] = out["n80_profit"] / n * 100
    return out
