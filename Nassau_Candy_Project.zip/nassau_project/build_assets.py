"""Generates report charts, Tableau-ready CSVs and a key-numbers file."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import analysis as a

ROOT = Path(__file__).parent
CH, TB = ROOT / "charts", ROOT / "tableau"
CH.mkdir(exist_ok=True); TB.mkdir(exist_ok=True)

COCOA, CARAMEL, BERRY, MINT, NAVY, GREY = "#3E2723", "#E09F3E", "#C8283C", "#2A9D8F", "#264653", "#8D99AE"
DIV_COL = {"Chocolate": COCOA, "Other": CARAMEL, "Sugar": MINT}
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "axes.titlesize": 13, "figure.dpi": 150,
                     "axes.edgecolor": "#999", "axes.grid": True, "grid.alpha": .25})
usd = FuncFormatter(lambda x, _: f"${x:,.0f}")

df, log = a.load_clean()
P = a.product_metrics(df)
D = a.division_metrics(df)
F = a.factory_metrics(df)
M = a.monthly_trend(df)
MD = a.monthly_trend(df, "Division")
R = a.region_metrics(df)
S = a.region_metrics(df, "State/Province")
CS = a.concentration_summary(df)
pp_prod = a.pareto(df, measure="Gross Profit")
ps_prod = a.pareto(df, measure="Sales")
pp_state = a.pareto(df, "State/Province", "Gross Profit")
pp_fact = a.pareto(df, "Factory", "Gross Profit")

short = lambda s: s.replace("Wonka Bar - ", "WB ")

# ------------------------------------------------------------------ Fig 1
fig, ax = plt.subplots(figsize=(9, 5.6))
q = P.sort_values("Gross Profit")
ax.barh(q["Product Name"].map(short), q["Gross Profit"], color=[DIV_COL[d] for d in q["Division"]])
ax.set_xscale("symlog", linthresh=10)
for i, (gp, gm) in enumerate(zip(q["Gross Profit"], q["Gross Margin %"])):
    ax.text(gp * 1.12 + 1, i, f"${gp:,.0f}  |  {gm:.1f}% GM", va="center", fontsize=8)
ax.set_xlim(0, 80000)
ax.xaxis.set_major_formatter(usd)
ax.set_title("Gross profit by product (log scale) with gross margin")
ax.set_xlabel("Gross profit (symlog axis)")
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=c, label=k) for k, c in DIV_COL.items()], loc="lower right", frameon=False)
fig.tight_layout(); fig.savefig(CH / "fig1_product_profit.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 2 quadrant
overall_gm = df["Gross Profit"].sum() / df["Sales"].sum() * 100
fig, ax = plt.subplots(figsize=(9, 5.6))
for _, r in P.iterrows():
    ax.scatter(r["Revenue Contribution %"], r["Gross Margin %"], s=max(r["Gross Profit"] / 40, 25),
               color=DIV_COL[r["Division"]], alpha=.8, edgecolor="white", linewidth=1)
lab = {"Wonka Bar - Nutty Crunch Surprise": (-135, 14), "Wonka Bar - Fudge Mallows": (-118, 0),
       "Wonka Bar - Milk Chocolate": (-100, -22), "Wonka Bar - Scrumdiddlyumptious": (14, 12),
       "Wonka Bar - Triple Dazzle Caramel": (14, -12), "Kazookles": (6, -14), "Lickable Wallpaper": (8, 6), "Wonka Gum": (8, 4), "Everlasting Gobstopper": (8, 4),
       "Hair Toffee": (6, 8), "Fizzy Lifting Drinks": (6, -2), "Laffy Taffy": (-8, 8)}
for _, r in P.iterrows():
    n = r["Product Name"]
    if r["Revenue Contribution %"] > 1 or n in ("Kazookles", "Lickable Wallpaper", "Wonka Gum", "Everlasting Gobstopper"):
        dx, dy = lab.get(n, (8, 6))
        ax.annotate(short(n), (r["Revenue Contribution %"], r["Gross Margin %"]), xytext=(dx, dy),
                    textcoords="offset points", fontsize=8,
                    arrowprops=dict(arrowstyle="-", color="#999", lw=.6) if r["Revenue Contribution %"] > 1 else None)
ax.set_xscale("log"); ax.set_xlim(0.006, 90)
ax.axhline(overall_gm, color=BERRY, ls="--", lw=1)
ax.text(0.0105, overall_gm + 1.2, f"Portfolio margin {overall_gm:.1f}%", color=BERRY, fontsize=8)
ax.axvline(100 / len(P), color=GREY, ls=":", lw=1)
ax.text(100 / len(P) * 1.05, 3, "Average product share (6.7%)", color=GREY, fontsize=8)
ax.set_xlabel("Revenue contribution % (log scale)"); ax.set_ylabel("Gross margin %")
ax.set_title("Product portfolio map: sales share vs margin (bubble = gross profit)")
ax.set_ylim(0, 90)
fig.tight_layout(); fig.savefig(CH / "fig2_portfolio_map.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 3 division
fig, axs = plt.subplots(1, 2, figsize=(10, 4.4), gridspec_kw={"width_ratios": [1.2, 1]})
x = np.arange(len(D)); w = .38
axs[0].bar(x - w / 2, D["Revenue Share %"], w, color=GREY, label="Revenue share")
axs[0].bar(x + w / 2, D["Profit Share %"], w, color=COCOA, label="Profit share")
for i, (rs, ps) in enumerate(zip(D["Revenue Share %"], D["Profit Share %"])):
    axs[0].text(i - w / 2, rs + 1, f"{rs:.1f}%", ha="center", fontsize=8)
    axs[0].text(i + w / 2, ps + 1, f"{ps:.1f}%", ha="center", fontsize=8)
axs[0].set_xticks(x); axs[0].set_xticklabels(D["Division"]); axs[0].set_ylim(0, 110)
axs[0].set_title("Revenue vs profit share"); axs[0].legend(frameon=False)
axs[1].bar(D["Division"], D["Gross Margin %"], color=[DIV_COL[d] for d in D["Division"]])
axs[1].axhline(overall_gm, color=BERRY, ls="--", lw=1)
for i, v in enumerate(D["Gross Margin %"]):
    axs[1].text(i, v + 1.2, f"{v:.1f}%", ha="center", fontsize=9)
axs[1].set_ylim(0, 85); axs[1].set_title("Gross margin by division")
fig.tight_layout(); fig.savefig(CH / "fig3_division.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 4 cost vs sales
fig, ax = plt.subplots(figsize=(8.5, 5.6))
xs = np.logspace(0.8, 4.6, 50)
for m, ls in [(0.25, ":"), (0.50, "--"), (0.659, "-")]:
    ax.plot(xs, xs * (1 - m), color=GREY if m < .6 else BERRY, ls=ls, lw=1)
    ax.text(11, 11 * (1 - m) * 1.18, f"{m*100:.0f}% margin" if m < .6 else "portfolio 65.9%", fontsize=7.5,
            color=GREY if m < .6 else BERRY, rotation=33, rotation_mode="anchor")
ax.scatter(P["Sales"], P["Cost"], s=70, c=[DIV_COL[d] for d in P["Division"]], edgecolor="white", zorder=3)
ax.annotate("5 Wonka Bars\n(95% of profit)", (26000, 9000), xytext=(-95, 45), textcoords="offset points", fontsize=8,
            arrowprops=dict(arrowstyle="-", color="#999", lw=.6))
for _, r in P.iterrows():
    if r["Product Name"] in ("Kazookles", "Wonka Gum", "Lickable Wallpaper"):
        ax.annotate(short(r["Product Name"]), (r["Sales"], r["Cost"]), xytext=(7, -12 if r["Product Name"] == "Kazookles" else 5),
                    textcoords="offset points", fontsize=8)
ax.set_xscale("log"); ax.set_yscale("log")
ax.xaxis.set_major_formatter(usd); ax.yaxis.set_major_formatter(usd)
ax.set_xlim(8, 60000); ax.set_ylim(4, 40000)
ax.set_xlabel("Total sales (log)"); ax.set_ylabel("Total cost (log)")
ax.set_title("Cost vs sales by product (points above a line have a lower margin)")
fig.tight_layout(); fig.savefig(CH / "fig4_cost_vs_sales.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 5 pareto
fig, axs = plt.subplots(1, 2, figsize=(11, 4.6))
ax = axs[0]
ax.bar(range(len(pp_prod)), pp_prod["Share %"], color=[COCOA if i < CS["n80_profit"] else GREY for i in range(len(pp_prod))])
ax.set_xticks(range(len(pp_prod))); ax.set_xticklabels([short(s) for s in pp_prod["Product Name"]], rotation=70, ha="right", fontsize=7)
ax.set_ylabel("Share of gross profit %"); ax.set_title("Product Pareto - gross profit")
ax2 = ax.twinx(); ax2.plot(range(len(pp_prod)), pp_prod["Cumulative %"], color=BERRY, marker="o", ms=3)
ax2.axhline(80, color=BERRY, ls="--", lw=.8); ax2.set_ylim(0, 105); ax2.spines["right"].set_visible(True); ax2.grid(False)
ax2.set_ylabel("Cumulative %")
ax = axs[1]
top = pp_state.head(15)
ax.bar(range(len(top)), top["Share %"], color=[NAVY if i < a.n_to_reach(pp_state) else GREY for i in range(len(top))])
ax.set_xticks(range(len(top))); ax.set_xticklabels(top["State/Province"], rotation=70, ha="right", fontsize=7)
ax.set_title(f"State Pareto - top 15 of {df['State/Province'].nunique()} (gross profit)")
ax3 = ax.twinx(); ax3.plot(range(len(top)), top["Cumulative %"], color=BERRY, marker="o", ms=3)
ax3.axhline(80, color=BERRY, ls="--", lw=.8); ax3.set_ylim(0, 105); ax3.grid(False); ax3.spines["right"].set_visible(True)
fig.tight_layout(); fig.savefig(CH / "fig5_pareto.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 6 trend
fig, ax = plt.subplots(figsize=(9.5, 4.2))
ax.bar(M["Month"], M["Sales"], width=22, color="#D7CCC8", label="Sales")
ax.bar(M["Month"], M["Gross Profit"], width=22, color=COCOA, label="Gross profit")
ax.yaxis.set_major_formatter(usd); ax.set_title("Monthly sales, gross profit and gross margin")
ax4 = ax.twinx(); ax4.plot(M["Month"], M["Gross Margin %"], color=BERRY, marker="o", ms=3, label="Gross margin %")
ax4.set_ylim(55, 75); ax4.grid(False); ax4.spines["right"].set_visible(True); ax4.set_ylabel("Gross margin %")
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax4.get_legend_handles_labels()
ax.legend(h1 + h2, l1 + l2, loc="upper left", frameon=False, ncol=3)
fig.tight_layout(); fig.savefig(CH / "fig6_monthly_trend.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 7 factory
fig, axs = plt.subplots(1, 2, figsize=(10, 4.2))
axs[0].barh(F["Factory"][::-1], F["Gross Profit"][::-1], color=NAVY)
axs[0].xaxis.set_major_formatter(usd); axs[0].set_xscale("symlog", linthresh=10)
for i, v in enumerate(F["Gross Profit"][::-1]):
    axs[0].text(v * 1.1, i, f"${v:,.0f}", va="center", fontsize=8)
axs[0].set_xlim(0, 150000); axs[0].set_title("Gross profit by factory (log)")
axs[1].barh(F["Factory"][::-1], F["Gross Margin %"][::-1], color=[BERRY if v < 25 else MINT for v in F["Gross Margin %"][::-1]])
for i, v in enumerate(F["Gross Margin %"][::-1]):
    axs[1].text(v + 1, i, f"{v:.1f}%", va="center", fontsize=8)
axs[1].set_xlim(0, 85); axs[1].set_title("Gross margin by factory")
fig.tight_layout(); fig.savefig(CH / "fig7_factory.png"); plt.close(fig)

# ------------------------------------------------------------------ scenarios
def reprice(cost_per_unit, price, units, target):
    new_price = cost_per_unit / (1 - target / 100)
    return new_price, (new_price / price - 1) * 100, (new_price - cost_per_unit) * units
scen = []
for name in ["Kazookles", "Lickable Wallpaper", "Wonka Gum", "SweeTARTS", "Fun Dip", "Nerds"]:
    r = P[P["Product Name"] == name].iloc[0]
    for tgt in (30, 50):
        if r["Gross Margin %"] >= tgt:
            continue
        npx, inc, newgp = reprice(r["Cost per Unit"], r["Avg Price per Unit"], r["Units"], tgt)
        scen.append({"Product": name, "Current price": r["Avg Price per Unit"], "Current cost/unit": r["Cost per Unit"],
                     "Current GM %": r["Gross Margin %"], "Target GM %": tgt, "Required price": npx,
                     "Price increase %": inc, "Profit uplift at constant units": newgp - r["Gross Profit"]})
SC = pd.DataFrame(scen)

# ------------------------------------------------------------------ Tableau CSVs
fact = df[["Row ID", "Order ID", "Order Date", "Ship Mode", "Customer ID", "Country/Region", "City", "State/Province",
           "Region", "Division", "Product ID", "Product Name", "Factory", "Sales", "Units", "Cost", "Gross Profit"]].copy()
fact["Order Date"] = fact["Order Date"].dt.strftime("%Y-%m-%d")
fact["Gross Margin %"] = (fact["Gross Profit"] / fact["Sales"]).round(6)   # stored as fraction for Tableau % format
fact["Profit per Unit"] = (fact["Gross Profit"] / fact["Units"]).round(4)
fact.to_csv(TB / "01_orders_clean.csv", index=False)
Pt = P.copy(); Pt["Gross Margin %"] /= 100; Pt["Cost Ratio %"] /= 100
Pt["Revenue Contribution %"] /= 100; Pt["Profit Contribution %"] /= 100
Pt.to_csv(TB / "02_product_metrics.csv", index=False)
D.to_csv(TB / "03_division_metrics.csv", index=False)
pp_prod.merge(ps_prod[["Product Name", "Sales", "Cumulative %"]].rename(columns={"Cumulative %": "Cumulative Sales %"}),
              on="Product Name").to_csv(TB / "04_pareto_products.csv", index=False)
M.to_csv(TB / "05_monthly_trend.csv", index=False)
MD.to_csv(TB / "06_monthly_by_division.csv", index=False)
F.to_csv(TB / "07_factory_metrics.csv", index=False)
S.to_csv(TB / "08_state_metrics.csv", index=False)
SC.to_csv(TB / "09_repricing_scenarios.csv", index=False)

# ------------------------------------------------------------------ key numbers
yr = df.groupby("Year").agg(Sales=("Sales", "sum"), GP=("Gross Profit", "sum"))
yr["GM"] = yr["GP"] / yr["Sales"] * 100
kpi = {
    "audit": log,
    "sales": float(df["Sales"].sum()), "cost": float(df["Cost"].sum()), "gp": float(df["Gross Profit"].sum()),
    "units": int(df["Units"].sum()), "gm": float(overall_gm), "ppu": float(df["Gross Profit"].sum() / df["Units"].sum()),
    "orders": int(df["Order ID"].nunique()), "lines": len(df), "customers": int(df["Customer ID"].nunique()),
    "states": int(df["State/Province"].nunique()),
    "date_min": str(df["Order Date"].min().date()), "date_max": str(df["Order Date"].max().date()),
    "year": yr.round(2).to_dict("index"),
    "conc": CS,
    "states80": int(a.n_to_reach(pp_state)), "state_top3": float(pp_state["Share %"].head(3).sum()),
    "state_top1": [pp_state["State/Province"].iloc[0], float(pp_state["Share %"].iloc[0])],
    "factory_top2": float(pp_fact["Share %"].head(2).sum()),
    "factory_top1": [pp_fact["Factory"].iloc[0], float(pp_fact["Share %"].iloc[0])],
    "region": R[["Region", "Sales", "Gross Profit", "Gross Margin %", "Profit Share %"]].round(2).to_dict("records"),
    "ship_mode_margin": df.groupby("Ship Mode").apply(lambda x: x["Gross Profit"].sum() / x["Sales"].sum() * 100, include_groups=False).round(2).to_dict(),
    "kaz_sales_share": float(P.loc[P["Product Name"] == "Kazookles", "Revenue Contribution %"].iloc[0]),
}
Path(ROOT / "key_numbers.json").write_text(json.dumps(kpi, indent=2, default=float))
P.to_pickle(ROOT / "_P.pkl"); D.to_pickle(ROOT / "_D.pkl"); F.to_pickle(ROOT / "_F.pkl"); SC.to_pickle(ROOT / "_SC.pkl")
print(json.dumps(kpi, indent=1, default=float)[:3500])
print(SC.round(2).to_string())
