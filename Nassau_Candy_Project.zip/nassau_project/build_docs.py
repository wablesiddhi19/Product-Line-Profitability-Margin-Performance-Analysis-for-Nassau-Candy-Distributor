"""Builds the research paper and the executive summary (.docx) from the same analytics module."""
import json
from pathlib import Path
from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Cm, RGBColor, Inches
import analysis as a

ROOT = Path(__file__).parent
CH = ROOT / "charts"
(ROOT / "docs").mkdir(exist_ok=True)
K = json.loads((ROOT / "key_numbers.json").read_text())
df, log = a.load_clean()
P, D, F = a.product_metrics(df), a.division_metrics(df), a.factory_metrics(df)
g = lambda n: P[P["Product Name"] == n].iloc[0]

COCOA, CARAMEL, BERRY = RGBColor(0x3E, 0x27, 0x23), RGBColor(0xE0, 0x9F, 0x3E), RGBColor(0xC8, 0x28, 0x3C)
FONT = "Arial"

# ----------------------------------------------------------------- derived numbers used in text
S, GP, GM = K["sales"], K["gp"], K["gm"]
choc = D[D["Division"] == "Chocolate"].iloc[0]
oth = D[D["Division"] == "Other"].iloc[0]
kaz, wall, milk, tri, scr, nut, fud, gum = [g(n) for n in
    ["Kazookles", "Lickable Wallpaper", "Wonka Bar - Milk Chocolate", "Wonka Bar - Triple Dazzle Caramel",
     "Wonka Bar - Scrumdiddlyumptious", "Wonka Bar - Nutty Crunch Surprise", "Wonka Bar - Fudge Mallows", "Wonka Gum"]]
bars = P[P["Product Name"].str.startswith("Wonka Bar")]
price1 = choc["Sales"] * 0.01
cost1 = choc["Cost"] * 0.01
tgt = fud["Gross Margin %"] / 100          # lift the two lowest-margin bars to Fudge Mallows' level
def lift(r, t):
    npx = r["Cost per Unit"] / (1 - t)
    return npx, (npx / r["Avg Price per Unit"] - 1) * 100, (npx - r["Avg Price per Unit"]) * r["Units"]
milk_l, tri_l = lift(milk, tgt), lift(tri, tgt)
kaz50 = lift(kaz, .5); kaz30 = lift(kaz, .3)
FM = F.set_index("Factory")["Gross Margin %"].to_dict()
yr = K["year"]
growth = (yr["2025"]["Sales"] / yr["2024"]["Sales"] - 1) * 100
conc = K["conc"]


# ----------------------------------------------------------------- docx helpers
def shade(cell, hex_):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), hex_)
    tcPr.append(shd)


def set_cell_margins(table, top=50, bottom=50, left=80, right=80):
    tblPr = table._tbl.tblPr
    m = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        e = OxmlElement(f"w:{k}"); e.set(qn("w:w"), str(v)); e.set(qn("w:type"), "dxa"); m.append(e)
    tblPr.append(m)


def new_doc(margin_cm=2.2):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(margin_cm); sec.top_margin = sec.bottom_margin = Cm(2.0)
    st = doc.styles["Normal"]; st.font.name = FONT; st.font.size = Pt(10.5)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    st.paragraph_format.space_after = Pt(6); st.paragraph_format.line_spacing = 1.12
    for name, size, col in (("Heading 1", 16, COCOA), ("Heading 2", 12.5, COCOA), ("Heading 3", 11, COCOA)):
        h = doc.styles[name]; h.font.name = FONT; h.font.size = Pt(size); h.font.bold = True; h.font.color.rgb = col
        h.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
        h.paragraph_format.space_before = Pt(14 if name == "Heading 1" else 10); h.paragraph_format.space_after = Pt(5)
        h.paragraph_format.keep_with_next = True
    return doc


def footer_pagenum(doc, text):
    p = doc.sections[0].footer.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text + "  |  Page "); r.font.size = Pt(8); r.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
    r2 = p.add_run(); r2.font.size = Pt(8)
    for t, txt in (("begin", None), (None, "PAGE"), ("end", None)):
        if t:
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), t); r2._r.append(e)
        else:
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt; r2._r.append(e)


def para(doc, text, bold=False, italic=False, size=None, color=None, align=None, after=None):
    p = doc.add_paragraph(); r = p.add_run(text); r.bold, r.italic = bold, italic
    if size: r.font.size = Pt(size)
    if color: r.font.color.rgb = color
    if align: p.alignment = align
    if after is not None: p.paragraph_format.space_after = Pt(after)
    return p


def rich(doc, parts, style=None):
    """parts: list of (text, bold) tuples."""
    p = doc.add_paragraph(style=style)
    for t, b in parts:
        r = p.add_run(t); r.bold = b
    return p


def bullet(doc, text, bold_lead=None):
    p = doc.add_paragraph(style="List Bullet"); p.paragraph_format.space_after = Pt(3)
    if bold_lead:
        p.add_run(bold_lead).bold = True
    p.add_run(text); return p


def table(doc, header, rows, widths_cm, font=8.5, align_right_from=1, zebra=True, highlight=None):
    t = doc.add_table(rows=1, cols=len(header)); t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.style = "Table Grid"; t.autofit = False
    set_cell_margins(t)
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]; c.text = ""; shade(c, "3E2723")
        r = c.paragraphs[0].add_run(h); r.bold = True; r.font.size = Pt(font); r.font.color.rgb = RGBColor(255, 255, 255)
        c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            r = cells[i].paragraphs[0].add_run(str(v)); r.font.size = Pt(font)
            if i >= align_right_from:
                cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
            if zebra and ri % 2 == 1: shade(cells[i], "FFF8E7")
            if highlight and highlight(ri, i, v): shade(cells[i], highlight(ri, i, v))
    for i, w in enumerate(widths_cm):
        t.columns[i].width = Cm(w)
    for row in t.rows:
        for i, w in enumerate(widths_cm):
            row.cells[i].width = Cm(w)
        for c in row.cells:
            c.paragraphs[0].paragraph_format.space_after = Pt(0)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def figure(doc, fname, caption, width_cm=16.2):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(str(CH / fname), width=Cm(width_cm))
    c = para(doc, caption, italic=True, size=8.5, color=RGBColor(0x66, 0x66, 0x66), align=WD_ALIGN_PARAGRAPH.CENTER, after=10)


def callout(doc, text, fill="FFF8E7"):
    t = doc.add_table(rows=1, cols=1); t.alignment = WD_TABLE_ALIGNMENT.CENTER; set_cell_margins(t, 90, 90, 140, 140)
    c = t.rows[0].cells[0]; shade(c, fill); c.text = ""
    r = c.paragraphs[0].add_run(text); r.font.size = Pt(10); c.paragraphs[0].paragraph_format.space_after = Pt(0)
    tcPr = c._tc.get_or_add_tcPr(); b = OxmlElement("w:tcBorders")
    l = OxmlElement("w:left"); l.set(qn("w:val"), "single"); l.set(qn("w:sz"), "24"); l.set(qn("w:color"), "E09F3E"); b.append(l); tcPr.append(b)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


usd = lambda v: f"${v:,.0f}"
pct = lambda v, d=1: f"{v:.{d}f}%"
risk_fill = {"Critical": "F4B6BD", "High": "F9D9A8", "Watch": "FFF2B3", "Healthy": "BFE5DF"}

# =================================================================== RESEARCH PAPER
doc = new_doc()
footer_pagenum(doc, "Nassau Candy Distributor - Product Line Profitability & Margin Performance")

# title block
p = para(doc, "RESEARCH PAPER", bold=True, size=9, color=CARAMEL, after=2)
p = para(doc, "Product Line Profitability & Margin Performance Analysis", bold=True, size=24, color=COCOA, after=2)
para(doc, "Nassau Candy Distributor", size=15, color=RGBColor(0x6D, 0x4C, 0x41), after=4)
para(doc, f"Exploratory data analysis, insights and recommendations | Order data {K['date_min']} to {K['date_max']} | "
          f"{K['lines']:,} order lines", italic=True, size=9, color=RGBColor(0x66, 0x66, 0x66), after=10)

doc.add_heading("Abstract", 1)
para(doc,
     f"Sales volume alone does not show which candy products make money. This paper analyses {K['lines']:,} order lines "
     f"({usd(S)} in sales, {usd(GP)} in gross profit, {pct(GM)} gross margin) for 15 products, 3 divisions and 5 factories. "
     f"The portfolio is profitable but extremely concentrated: five Wonka Bar products deliver {pct(conc['top5_profit_share'])} of gross profit "
     f"and two factories supply all of them. Margin problems are real but small in dollar terms and sit in the long tail: "
     f"Kazookles earns {pct(kaz['Gross Margin %'])} margin, three Sugar products sit below 50%, and the 'Other' division runs at "
     f"{pct(oth['Gross Margin %'])} against {pct(choc['Gross Margin %'])} for Chocolate. Margin is determined by the product, not by "
     f"region, shipping mode or time. The biggest controllable levers are therefore (1) pricing and sourcing of the five bars, "
     f"(2) repricing or rationalising Kazookles, and (3) reducing dependency on one factory and a handful of SKUs.")

doc.add_heading("Key findings at a glance", 2)
table(doc, ["#", "Finding", "Evidence"], [
    ["1", "Profit is concentrated in five products", f"Top 5 = {pct(conc['top5_profit_share'])} of profit; 5 of 15 products (33%) give both 80% of revenue and 80% of profit; HHI {conc['hhi_profit']:,.0f}"],
    ["2", "Higher sales do not always mean higher margin", f"Triple Dazzle Caramel is #1 by sales ({pct(tri['Revenue Contribution %'])}) but #6 by margin ({pct(tri['Gross Margin %'])}); Nutty Crunch is #5 by sales but the top bar by margin ({pct(nut['Gross Margin %'])})"],
    ["3", "One product is a clear margin risk", f"Kazookles: price ${kaz['Avg Price per Unit']:.2f} vs cost ${kaz['Cost per Unit']:.2f} per unit = {pct(kaz['Gross Margin %'])} margin on {usd(kaz['Sales'])} sales"],
    ["4", "Division 'Other' dilutes margin", f"{pct(oth['Gross Margin %'])} margin; {pct(oth['Revenue Share %'])} of revenue but {pct(oth['Profit Share %'])} of profit"],
    ["5", "Margin is product-driven", f"Region margins {min(r['Gross Margin %'] for r in K['region']):.1f}-{max(r['Gross Margin %'] for r in K['region']):.1f}%; ship-mode margins {min(K['ship_mode_margin'].values()):.1f}-{max(K['ship_mode_margin'].values()):.1f}%; monthly product margin never moves"],
    ["6", "Supply risk is as large as margin risk", f"{K['factory_top1'][0]} supplies {pct(K['factory_top1'][1])} of profit; two factories supply {pct(K['factory_top2'])}"],
], [0.8, 5.2, 10.4], font=8.5, align_right_from=99)

# 1 Introduction
doc.add_heading("1. Introduction and objectives", 1)
para(doc, "Distributors such as Nassau Candy can look successful on volume while earning little on some products, "
          "consuming disproportionate manufacturing cost, or weakening overall margins. Without product-level margin visibility, pricing, "
          "promotion and portfolio decisions stay reactive. This study answers four questions:")
for t in ["Which product lines deliver the highest gross margin and the largest profit contribution?",
          "Are the high-sales products actually profitable?",
          "How does profitability vary across product divisions?",
          "Which products represent margin risk, and what action does each need (reprice, renegotiate cost, review for discontinuation)?"]:
    bullet(doc, t)

# 2 Data & method
doc.add_heading("2. Data and methodology", 1)
doc.add_heading("2.1 Dataset", 2)
para(doc, f"The source file contains {log['rows_in']:,} order lines from {K['customers']:,} customers in {K['states']} states/provinces, "
          f"covering {K['orders']:,} orders placed between {K['date_min']} and {K['date_max']}. Each line carries the product, division, region, "
          "sales value, units, cost and gross profit. A factory attribute was added from the product-to-factory table supplied in the project brief.")
doc.add_heading("2.2 Cleaning and validation", 2)
table(doc, ["Check", "Result", "Action"], [
    ["Zero / negative sales, cost or units", "0 rows", "None needed"],
    ["Missing units", "0 rows", "Imputation rule (median unit price) built in, not triggered"],
    ["Gross Profit = Sales - Cost", "0 mismatches (tolerance $0.02)", "Recalculation rule built in, not triggered"],
    ["Duplicate rows / Row IDs", "0", "None needed"],
    ["Label standardisation", "1 product label inconsistent ('Wonka Bar -Scrumdiddlyumptious')", "Standardised spacing around the hyphen"],
    ["Ship Date plausibility", f"Median {log['ship_lag_days_median']:,} days after Order Date (about 3.5 years)", "Ship Date excluded; irrelevant to profitability but flagged for the data owner"],
    ["Division label vs brief", "'Fizzy Lifting Drinks' is Sugar in the data, Other in the brief's table", "Dataset label kept (6 lines, $79 sales); flagged"],
    ["Order ID prefix", "IDs read 'US-2021-...' while order dates are 2024-2025", "Order ID used only as a key; flagged"],
], [4.6, 6.0, 5.8], font=8.5, align_right_from=99)
doc.add_heading("2.3 Metric definitions", 2)
table(doc, ["KPI", "Definition"], [
    ["Gross Margin %", "Gross Profit / Sales (computed on aggregates, not averaged across rows)"],
    ["Profit per Unit", "Gross Profit / Units"],
    ["Revenue Contribution", "Product sales / total sales"],
    ["Profit Contribution", "Product gross profit / total gross profit"],
    ["Margin Volatility", "Standard deviation of monthly gross margin, in percentage points"],
    ["Segment", "Star: revenue share >= average (1/15 = 6.7%) and margin >= threshold; Volume trap: high share, margin below threshold; Niche premium: low share, high margin; Under-performer: low share, low margin"],
    ["Risk flag", "Critical < 25% margin; High < 50%; Watch < threshold (default = portfolio margin 65.9%); Healthy otherwise"],
    ["Pareto / HHI", "Items needed to reach 80% of revenue or profit; Herfindahl-Hirschman index of profit shares (above 2,500 = highly concentrated)"],
], [3.6, 12.8], font=8.5, align_right_from=99)

# 3 EDA
doc.add_heading("3. Exploratory data analysis", 1)
doc.add_heading("3.1 Portfolio overview", 2)
para(doc, f"Total sales were {usd(S)} with {usd(K['cost'])} of cost, leaving {usd(GP)} of gross profit ({pct(GM)}) on {K['units']:,} units, "
          f"or ${K['ppu']:.2f} gross profit per unit. Sales grew {growth:.0f}% from {usd(yr['2024']['Sales'])} in 2024 to {usd(yr['2025']['Sales'])} in 2025, "
          f"while gross margin was essentially unchanged ({yr['2024']['GM']:.1f}% to {yr['2025']['GM']:.1f}%). Growth has therefore come from volume, "
          "not from better pricing or cost control.")
figure(doc, "fig6_monthly_trend.png", "Figure 1. Monthly sales, gross profit and gross margin. Margin is flat while volume grows.")
doc.add_heading("3.2 Margin is not explained by geography or shipping", 2)
rr = K["region"]
table(doc, ["Region", "Sales", "Gross profit", "Gross margin", "Profit share"],
      [[r["Region"], usd(r["Sales"]), usd(r["Gross Profit"]), pct(r["Gross Margin %"]), pct(r["Profit Share %"])] for r in rr],
      [3.4, 3.0, 3.0, 3.0, 3.0], font=8.5)
para(doc, f"Regional margins differ by less than one percentage point, and ship-mode margins by about {max(K['ship_mode_margin'].values()) - min(K['ship_mode_margin'].values()):.1f} points. "
          "Margin differences are therefore a product and pricing story, not a regional or logistics one. (Shipping cost is not in the dataset, "
          "so the gross-margin view excludes freight.)")

# 4 product
doc.add_heading("4. Product-level profitability", 1)
rows = []
for _, r in P.iterrows():
    rows.append([r["Product Name"], r["Division"], usd(r["Sales"]), usd(r["Gross Profit"]), pct(r["Gross Margin %"]),
                 f"${r['Profit per Unit']:.2f}", pct(r["Revenue Contribution %"], 2), pct(r["Profit Contribution %"], 2),
                 r["Segment"], r["Risk Flag"]])
table(doc, ["Product", "Div.", "Sales", "Gross profit", "Margin", "Profit /unit", "Rev. contr.", "Profit contr.", "Segment", "Risk"],
      [[x.replace("Wonka Bar - ", "WB ") if i == 0 else x for i, x in enumerate(r)] for r in rows],
      [3.5, 1.5, 1.4, 1.5, 1.2, 1.2, 1.2, 1.2, 1.9, 1.3], font=7, align_right_from=2,
      highlight=lambda ri, ci, v: risk_fill.get(v) if ci == 9 else None)
para(doc, "Table 1. Product scorecard, ranked by gross profit. 'WB' = Wonka Bar.", italic=True, size=8.5, color=RGBColor(0x66, 0x66, 0x66), after=8)
figure(doc, "fig1_product_profit.png", "Figure 2. Gross profit and gross margin by product (log axis so small products are visible).")
doc.add_heading("4.1 High-profit, high-margin products", 2)
para(doc, f"Wonka Bar - Scrumdiddlyumptious is the largest profit contributor ({usd(scr['Gross Profit'])}, {pct(scr['Profit Contribution %'])} of profit) with a "
          f"strong {pct(scr['Gross Margin %'])} margin. Nutty Crunch Surprise has the best margin of the main bars ({pct(nut['Gross Margin %'])}) because its cost per unit "
          f"is only ${nut['Cost per Unit']:.2f}. Fudge Mallows ({pct(fud['Gross Margin %'])}) is also above the portfolio average. These three are the 'Star' products to protect.")
doc.add_heading("4.2 High-sales, lower-margin products", 2)
para(doc, f"Triple Dazzle Caramel has the highest sales of any product ({usd(tri['Sales'])}) but only a {pct(tri['Gross Margin %'])} margin; Milk Chocolate has the most units "
          f"({milk['Units']:,.0f}) and the lowest bar margin ({pct(milk['Gross Margin %'])}) because it is priced at ${milk['Avg Price per Unit']:.2f} against "
          f"${nut['Avg Price per Unit']:.2f}-${tri['Avg Price per Unit']:.2f} for its siblings. Both are produced at Wicked Choccy's, whose factory margin is "
          f"{pct(FM[chr(87) + 'icked Choccy' + chr(39) + 's'])} against {pct(FM['Lot' + chr(39) + 's O' + chr(39) + ' Nuts'])} at Lot's O' Nuts. "
          "These products fall only 0.6-1.0 points below the portfolio average, so 'volume trap' here means a gap worth closing, not a loss-maker.")
callout(doc, f"Illustrative lever: lifting Milk Chocolate and Triple Dazzle Caramel to Fudge Mallows' margin ({pct(tgt * 100)}) needs price rises of about "
             f"{milk_l[1]:.0f}% (to ${milk_l[0]:.2f}) and {tri_l[1]:.0f}% (to ${tri_l[0]:.2f}), worth roughly {usd(milk_l[2] + tri_l[2])} of gross profit at constant volume. "
             f"For scale, every 1% price increase across the five bars is worth about {usd(price1)}, and every 1% cut in their unit cost about {usd(cost1)}.")
doc.add_heading("4.3 Low-sales, low-profit products", 2)
para(doc, "Ten products together generate under 8% of sales and under 5.5% of profit. Wonka Gum, Fizzy Lifting Drinks, Laffy Taffy, SweeTARTS, Nerds and Fun Dip are "
          "'Under-performers' by the segmentation rule; their order counts (3 to 120 lines over two years) are too small for firm conclusions. "
          "Everlasting Gobstopper and Hair Toffee have high margins (80% and 78%) on tiny volumes - 'Niche premium' items that could be cross-sold.")
figure(doc, "fig2_portfolio_map.png", "Figure 3. Portfolio map. Five bars dominate the top-right; Kazookles is the lone deep-margin outlier at the bottom.")
doc.add_heading("4.4 Lickable Wallpaper: small but valuable per unit", 2)
para(doc, f"Lickable Wallpaper earns ${wall['Profit per Unit']:.2f} gross profit per unit, about four times the bars (${bars['Gross Profit'].sum() / bars['Units'].sum():.2f}), "
          f"and contributes {pct(wall['Profit Contribution %'])} of profit on {pct(wall['Revenue Contribution %'])} of sales. Its 50.0% margin is below the portfolio average, "
          "yet each additional unit is worth far more than a bar. It is the best growth candidate outside the core range.")

# 5 division
doc.add_heading("5. Division-level performance", 1)
table(doc, ["Division", "Products", "Sales", "Gross profit", "Margin", "Profit/unit", "Rev. share", "Profit share", "Gap (pp)"],
      [[r["Division"], int(r["Products"]), usd(r["Sales"]), usd(r["Gross Profit"]), pct(r["Gross Margin %"]), f"${r['Profit per Unit']:.2f}",
        pct(r["Revenue Share %"]), pct(r["Profit Share %"]), f"{r['Profit - Revenue Gap (pp)']:+.1f}"] for _, r in D.iterrows()],
      [2.4, 1.6, 2.0, 2.0, 1.7, 1.7, 1.8, 1.8, 1.5], font=8)
figure(doc, "fig3_division.png", "Figure 4. Division revenue vs profit share (left) and gross margin (right).", 15.2)
bullet(doc, f" {pct(choc['Revenue Share %'])} of sales, {pct(choc['Profit Share %'])} of profit, {pct(choc['Gross Margin %'])} margin. Strong financial efficiency; profit share exceeds revenue share by {choc['Profit - Revenue Gap (pp)']:.1f} points.", "Chocolate:")
bullet(doc, f" {pct(oth['Gross Margin %'])} margin, {abs(oth['Profit - Revenue Gap (pp)']):.1f} points less profit than revenue share. Structural issue: its cost ratio is {pct(oth['Cost Ratio %'])} of sales against {pct(choc['Cost Ratio %'])} for Chocolate. The cause is Kazookles ({pct(kaz['Gross Margin %'])}); Lickable Wallpaper and Wonka Gum sit near 50%.", "Other:")
bullet(doc, f" {pct(D[D['Division'] == 'Sugar'].iloc[0]['Gross Margin %'])} margin overall, but only 0.3% of sales across seven products; the average product margin is 59% and three products are below 50%. Too small to move the totals.", "Sugar:")
para(doc, "Margin volatility is zero at product level because every product sells at one price and one cost for the whole period. Division-level swings "
          "(10-11 points for Other and Sugar, 0.2 for Chocolate) reflect product mix in months with very few orders, not pricing or cost movements.")

# 6 pareto
doc.add_heading("6. Profit concentration (Pareto) analysis", 1)
figure(doc, "fig5_pareto.png", "Figure 5. Pareto charts for products (left) and states (right). Dark bars reach 80% cumulative profit.", 16.4)
table(doc, ["Indicator", "Value"], [
    ["Products needed for 80% of revenue", f"{conc['n80_rev']} of {conc['n_products']} ({pct(conc['pct80_rev'], 0)})"],
    ["Products needed for 80% of gross profit", f"{conc['n80_profit']} of {conc['n_products']} ({pct(conc['pct80_profit'], 0)})"],
    ["Top-1 / top-3 / top-5 product profit share", f"{pct(conc['top1_profit_share'])} / {pct(conc['top3_profit_share'])} / {pct(conc['top5_profit_share'])}"],
    ["Profit HHI (0-10,000)", f"{conc['hhi_profit']:,.0f} (15 equal products would score 667; 5 equal products 2,000)"],
    ["Factory dependency", f"{K['factory_top1'][0]} {pct(K['factory_top1'][1])}; top two factories {pct(K['factory_top2'])}"],
    ["Geographic dependency", f"{K['states80']} of {K['states']} states give 80% of profit; {K['state_top1'][0]} alone {pct(K['state_top1'][1])}; top three states {pct(K['state_top3'])}"],
], [6.6, 9.8], font=8.5, align_right_from=99)
para(doc, "The product concentration is high but is partly structural: the five bars are the core chocolate range. The more important exposure is operational. "
          "Every bar is made at one of two factories, so a disruption at Lot's O' Nuts would put more than half of gross profit at risk. "
          "Geographic dependency is moderate (California is about a fifth of profit) and in line with a national distributor.")

# 7 cost
doc.add_heading("7. Cost structure diagnostics", 1)
figure(doc, "fig4_cost_vs_sales.png", "Figure 6. Cost versus sales by product (log-log). Distance above the red line shows margin shortfall.", 14.5)
para(doc, f"Cost-to-sales ratios cluster at 29-35% for the bars, which is why they sit on one line. Kazookles stands apart at {pct(kaz['Cost Ratio %'])}: it costs "
          f"${kaz['Cost per Unit']:.2f} to make and sells for ${kaz['Avg Price per Unit']:.2f}, leaving ${kaz['Profit per Unit']:.2f} per unit. Lickable Wallpaper "
          f"({pct(wall['Cost Ratio %'])}) and Wonka Gum ({pct(gum['Cost Ratio %'])}) carry cost ratios of 48-50%, and three Sugar items (SweeTARTS, Nerds, Fun Dip) are between 53% and 60%. "
          "Kazookles and Fun Dip are the clearest pricing inefficiencies; The Other Factory, which makes Kazookles and Hair Toffee, has an 11.9% factory margin.")
table(doc, ["Product", "Price", "Cost/unit", "Margin", "Flag", "Price for 30% GM", "Price for 50% GM", "Recommended action"],
      [[r["Product Name"], f"${r['Avg Price per Unit']:.2f}", f"${r['Cost per Unit']:.2f}", pct(r["Gross Margin %"]), r["Risk Flag"],
        (f"${r['Cost per Unit'] / .7:.2f}" if r["Gross Margin %"] < 30 else "met"),
        (f"${r['Cost per Unit'] / .5:.2f}" if r["Gross Margin %"] < 50 else "met"), r["Recommended Action"]]
       for _, r in P[P["Risk Flag"].isin(["Critical", "High"])].iterrows()] +
      [[wall["Product Name"], f"${wall['Avg Price per Unit']:.2f}", f"${wall['Cost per Unit']:.2f}", pct(wall["Gross Margin %"]), "Watch", "met", "met",
        "Monitor; grow volume, test small price rise"]],
      [2.8, 1.3, 1.5, 1.3, 1.4, 1.9, 1.9, 4.5], font=7.5, align_right_from=1,
      highlight=lambda ri, ci, v: risk_fill.get(v) if ci == 4 else None)
callout(doc, f"Kazookles needs a price of ${kaz30[0]:.2f} (+{kaz30[1]:.0f}%) to reach 30% margin or ${kaz50[0]:.2f} (+{kaz50[1]:.0f}%) to reach 50%. A rise of that size could "
             f"cut demand sharply, so the alternative is cost renegotiation (unit cost down to ${kaz['Avg Price per Unit'] * .7:.2f} for 30%). If neither is feasible, "
             f"the discontinuation review is easy to justify: the product earns {usd(kaz['Gross Profit'])} in two years, which is {pct(kaz['Profit Contribution %'], 2)} of profit, "
             f"while occupying {int(kaz['Order Lines'])} order lines and {usd(kaz['Cost'])} of cost.")
para(doc, "Repricing every below-target product to 50% margin would add only about $1,028 (1.1% of gross profit) at constant volume. The dollar prize in the tail is small; "
          "the case for acting is margin hygiene and management focus, while the larger dollar levers are price and cost on the five core bars.")
doc.add_heading("7.1 Factory economics", 2)
figure(doc, "fig7_factory.png", "Figure 7. Gross profit and margin by factory.", 14.5)

# 8 recommendations
doc.add_heading("8. Recommendations", 1)
table(doc, ["Priority", "Action", "Why", "Indicative impact"], [
    ["1", "Review price and cost on Milk Chocolate and Triple Dazzle Caramel (Wicked Choccy's)", "Highest-volume bars with margins 1-6 points below the other bars", f"About {usd(milk_l[2] + tri_l[2])} if both reach {pct(tgt * 100)} margin; each 1% price on all bars = {usd(price1)}"],
    ["2", "Reprice or renegotiate Kazookles; schedule a discontinuation review if no improvement within two quarters", "7.7% margin; cost is 92% of sales; drags Other division", f"Up to {usd(kaz50[2])} at 50% margin (constant volume); removes the largest margin outlier"],
    ["3", "Secure and dual-source the five bars; assess capacity and continuity plans for Lot's O' Nuts and Wicked Choccy's", "95% of profit depends on two factories", "Risk reduction (not quantified in this data)"],
    ["4", "Grow Lickable Wallpaper through targeted promotion and bundling; test a small price rise", f"${wall['Profit per Unit']:.2f} profit per unit, about 4x a bar", "Each extra 100 units adds about $1,000 gross profit"],
    ["5", "Cost renegotiation or small price rises on SweeTARTS, Nerds and Fun Dip; fold the Sugar tail into a rationalisation review", "Margins 40-47% on very low volume", "Small in dollars; simplifies range"],
    ["6", "Cross-sell Everlasting Gobstopper and Hair Toffee (78-80% margin) to existing bar customers", "High margin, almost no distribution today", "Upside depends on demand test"],
    ["7", "Adopt this dashboard monthly; add freight and promotion costs to move from gross to contribution margin", "Current view excludes shipping and trade spend", "Better decisions"],
], [1.3, 5.4, 4.7, 5.0], font=8, align_right_from=99)

# 9 limitations
doc.add_heading("9. Limitations", 1)
for t in [
    "Gross margin only: freight, promotions, overheads and returns are not in the dataset, so true contribution margin is lower and may vary by region and ship mode.",
    "Each product has a single fixed price and unit cost for the whole period, so price elasticity and cost trends cannot be estimated; all scenarios hold volume constant and are upper bounds.",
    "Ten of 15 products have fewer than 130 order lines over two years; conclusions on the Sugar tail are indicative.",
    "Ship Date, the Order ID year prefix and one division label are inconsistent with other fields. They do not affect margin results but should be corrected at source.",
    "The Streamlit and Excel models use identical definitions; Tableau needs the calculated fields in the build guide to match.",
]:
    bullet(doc, t)

doc.add_heading("Appendix: deliverables", 1)
table(doc, ["Deliverable", "File"], [
    ["Streamlit dashboard (live analytics)", "app.py, analysis.py"],
    ["Excel model (795 live formulas, charts)", "Nassau_Candy_Profitability_Analysis.xlsx"],
    ["Tableau data and build guide", "tableau/ (9 CSVs + TABLEAU_GUIDE.md)"],
    ["Executive summary", "docs/Nassau_Candy_Executive_Summary.docx"],
], [7.5, 8.9], font=9, align_right_from=99)
doc.save(ROOT / "docs" / "Nassau_Candy_Research_Paper.docx")

# =================================================================== EXECUTIVE SUMMARY
ex = new_doc(2.0)
footer_pagenum(ex, "Nassau Candy Distributor - Executive Summary")
para(ex, "EXECUTIVE SUMMARY", bold=True, size=9, color=CARAMEL, after=2)
para(ex, "Which candy products really make money?", bold=True, size=21, color=COCOA, after=2)
para(ex, f"Nassau Candy Distributor | Orders {K['date_min']} to {K['date_max']} | {K['lines']:,} order lines", italic=True, size=9,
     color=RGBColor(0x66, 0x66, 0x66), after=8)

# KPI strip
t = ex.add_table(rows=2, cols=5); t.alignment = WD_TABLE_ALIGNMENT.CENTER; set_cell_margins(t, 70, 70, 80, 80)
kp = [("Sales", usd(S)), ("Gross profit", usd(GP)), ("Gross margin", pct(GM)), ("Units sold", f"{K['units']:,}"), ("Profit per unit", f"${K['ppu']:.2f}")]
for i, (l_, v_) in enumerate(kp):
    c0, c1 = t.rows[0].cells[i], t.rows[1].cells[i]
    shade(c0, "3E2723"); shade(c1, "FFF8E7"); c0.text = c1.text = ""
    r = c0.paragraphs[0].add_run(l_.upper()); r.font.size = Pt(7.5); r.bold = True; r.font.color.rgb = RGBColor(255, 255, 255)
    r = c1.paragraphs[0].add_run(v_); r.font.size = Pt(14); r.bold = True; r.font.color.rgb = COCOA
    for c in (c0, c1):
        c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER; c.paragraphs[0].paragraph_format.space_after = Pt(0)
ex.add_paragraph().paragraph_format.space_after = Pt(0)

ex.add_heading("The bottom line", 2)
para(ex, f"Nassau Candy is healthy, earning {pct(GM)} gross margin, but it depends on very few products. Five Wonka Bars produce {pct(conc['top5_profit_share'])} of profit "
         f"and are made in two factories. A small tail of products earns thin margins, though it matters little in dollars. "
         f"The big opportunities are protecting the core range and tuning its price and cost, not rescuing the tail.")

ex.add_heading("What we found", 2)
bullet(ex, f" Five of 15 products give 80% of sales and 80% of profit. Scrumdiddlyumptious alone is {pct(scr['Profit Contribution %'])} of profit.", "Profit is concentrated.")
bullet(ex, f" Triple Dazzle Caramel sells the most ({usd(tri['Sales'])}) yet earns {pct(tri['Gross Margin %'])} margin; Nutty Crunch sells least of the five bars but earns {pct(nut['Gross Margin %'])}.", "Top sellers are not always top earners.")
bullet(ex, f" It costs ${kaz['Cost per Unit']:.2f} to make and sells for ${kaz['Avg Price per Unit']:.2f}: a {pct(kaz['Gross Margin %'])} margin. It pulls the 'Other' division down to {pct(oth['Gross Margin %'])} versus {pct(choc['Gross Margin %'])} for Chocolate.", "Kazookles is the margin risk.")
bullet(ex, f" Lickable Wallpaper earns ${wall['Profit per Unit']:.2f} profit per unit, about four times a bar.", "A quiet bright spot.")
bullet(ex, f" Region, shipping mode and month barely change margin (all within about one point). Product and pricing decide profitability.", "Margin comes from the product, not the place.")
bullet(ex, f" {K['factory_top1'][0]} supplies {pct(K['factory_top1'][1])} of profit; two factories supply {pct(K['factory_top2'])}. Sales grew {growth:.0f}% in 2025 but margin did not improve.", "Supply and growth quality.")

figure(ex, "fig1_product_profit.png", "Gross profit and margin by product (log scale).", 10.2)

ex.add_heading("What we recommend", 2)
table(ex, ["#", "Action", "Impact"], [
    ["1", "Test modest price rises and unit-cost savings on Milk Chocolate and Triple Dazzle Caramel", f"~{usd(milk_l[2] + tri_l[2])}; each 1% price on all bars = {usd(price1)}"],
    ["2", "Reprice or renegotiate Kazookles; review for discontinuation if no improvement in two quarters", "Removes the largest margin outlier"],
    ["3", "Reduce reliance on two factories: dual-sourcing and continuity plans for the five bars", "Protects 95% of profit"],
    ["4", "Promote and bundle Lickable Wallpaper; cross-sell Gobstopper and Hair Toffee", "High profit per unit"],
    ["5", "Review the thin-margin Sugar items (SweeTARTS, Nerds, Fun Dip) for cost or price fixes", "Simpler, healthier range"],
    ["6", "Track margins monthly on the new dashboard; add freight and promotion costs next", "Moves reporting from gross to contribution margin"],
], [0.8, 10.2, 6.0], font=8.5, align_right_from=99)

ex.add_heading("What to keep in mind", 2)
para(ex, "Figures are gross margins before freight, promotions and overheads. Scenarios assume sales volumes stay the same when prices change, "
         "so they are upper bounds. Several date and label fields in the source data are inconsistent and should be corrected at source; "
         "they do not change the profitability results.", size=9.5)
ex.save(ROOT / "docs" / "Nassau_Candy_Executive_Summary.docx")
print("docs saved")
