"""Builds the formula-driven Excel analysis workbook."""
from pathlib import Path
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, ScatterChart, LineChart, Reference, Series
from openpyxl.chart.label import DataLabelList
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.utils import get_column_letter as L
import analysis as a

ROOT = Path(__file__).parent
df, log = a.load_clean()
P = a.product_metrics(df)

FONT = "Arial"
COCOA, CARAMEL, CREAM, BERRY, MINT = "3E2723", "E09F3E", "FFF8E7", "C8283C", "2A9D8F"
hdr_font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
hdr_fill = PatternFill("solid", fgColor=COCOA)
base = Font(name=FONT, size=10)
bold = Font(name=FONT, size=10, bold=True)
inp = Font(name=FONT, size=10, color="0000FF", bold=True)
inp_fill = PatternFill("solid", fgColor="FFFF99")
thin = Side(style="thin", color="D9D9D9")
box = Border(left=thin, right=thin, top=thin, bottom=thin)
USD, USD2, PCT, INT = '$#,##0;($#,##0);"-"', '$#,##0.00;($#,##0.00);"-"', '0.0%', '#,##0'


def header(ws, row, labels, col=1):
    for i, t in enumerate(labels):
        c = ws.cell(row=row, column=col + i, value=t)
        c.font, c.fill, c.border = hdr_font, hdr_fill, box
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 32


def title(ws, text, sub=None):
    ws["A1"] = text
    ws["A1"].font = Font(name=FONT, size=16, bold=True, color=COCOA)
    if sub:
        ws["A2"] = sub
        ws["A2"].font = Font(name=FONT, size=9, italic=True, color="666666")
    ws.sheet_view.showGridLines = False


def widths(ws, ws_widths):
    for i, w in enumerate(ws_widths, 1):
        ws.column_dimensions[L(i)].width = w


wb = Workbook()

# ===================================================================== Data
wd = wb.active; wd.title = "Data"
cols = ["Row ID", "Order ID", "Order Date", "Month", "Ship Mode", "Customer ID", "State/Province", "Region",
        "Division", "Product ID", "Product Name", "Factory", "Sales", "Units", "Cost", "Gross Profit"]
header(wd, 1, cols)
out = df[cols].copy()
for r, row in enumerate(out.itertuples(index=False), start=2):
    for c, v in enumerate(row, start=1):
        if isinstance(v, pd.Timestamp):
            v = v.to_pydatetime()
        wd.cell(row=r, column=c, value=v)
N = len(out) + 1
for col, fmt in [("C", "yyyy-mm-dd"), ("D", "mmm-yy"), ("M", USD2), ("O", USD2), ("P", USD2)]:
    for r in range(2, N + 1):
        wd[f"{col}{r}"].number_format = fmt
widths(wd, [8, 30, 12, 9, 14, 11, 16, 10, 11, 15, 34, 18, 10, 7, 10, 12])
wd.freeze_panes = "A2"
wd.auto_filter.ref = f"A1:{L(len(cols))}{N}"
rng = lambda col: f"Data!${col}$2:${col}${N}"
R_DIV, R_PROD, R_SALES, R_UNITS, R_COST, R_GP, R_MONTH, R_FACT, R_REG, R_STATE = (
    rng("I"), rng("K"), rng("M"), rng("N"), rng("O"), rng("P"), rng("D"), rng("L"), rng("H"), rng("G"))

# ===================================================================== Assumptions
wa = wb.create_sheet("Assumptions")
title(wa, "Assumptions & Controls", "Blue cells on yellow are inputs - change them and every sheet recalculates.")
rows = [
    ("Margin threshold for 'Watch' flag (gross margin)", None, PCT, "Default = portfolio margin (formula). Overwrite with a number such as 0.60 to test."),
    ("'High' risk below (gross margin)", 0.50, PCT, "Products below this need cost renegotiation / price rise."),
    ("'Critical' risk below (gross margin)", 0.25, PCT, "Products below this need repricing + discontinuation review."),
    ("Avg product revenue share (for Star / Volume-trap split)", None, PCT, "Equals 1 divided by the number of products (formula)."),
    ("Pareto target share", 0.80, PCT, "Used for the '80%' cut-off on the Pareto sheet."),
]
header(wa, 4, ["Parameter", "Value", "Note"])
for i, (lab, val, fmt, note) in enumerate(rows, start=5):
    wa.cell(row=i, column=1, value=lab).font = base
    c = wa.cell(row=i, column=2, value=val); c.number_format = fmt
    wa.cell(row=i, column=3, value=note).font = Font(name=FONT, size=9, italic=True, color="666666")
wa["B5"] = "=Product_Analysis!K22"      # portfolio margin
wa["B5"].font = base
wa["B8"] = "=1/COUNTA(Product_Analysis!B5:B19)"
wa["B8"].font = base
for ref in ("B6", "B7", "B9"):
    wa[ref].font, wa[ref].fill = inp, inp_fill
wa["B5"].number_format = wa["B8"].number_format = PCT
wa["A11"] = "Data notes"; wa["A11"].font = bold
notes = [
    f"Source: Nassau_Candy_Distributor.csv ({log['rows_in']:,} order lines, orders dated {df['Order Date'].min():%d %b %Y} to {df['Order Date'].max():%d %b %Y}).",
    "Validation: no zero/negative sales, missing units, duplicates or Sales-Cost-Gross Profit mismatches were found; 0 rows removed.",
    "Labels standardised: 'Wonka Bar -Scrumdiddlyumptious' -> 'Wonka Bar - Scrumdiddlyumptious'.",
    "Factory column added from the product-to-factory table in the project brief.",
    "Ship Date is excluded: it falls ~3.5 years after Order Date on every row (a data-quality issue); it does not affect profitability.",
    "Fizzy Lifting Drinks: dataset labels it 'Sugar'; the brief's mapping table says 'Other'. The dataset label is kept (6 order lines, $79 sales).",
    "Margin volatility is ~0 per product because each product sells at one fixed price and cost; division volatility reflects mix only.",
]
for i, n in enumerate(notes, start=12):
    wa.cell(row=i, column=1, value=n).font = Font(name=FONT, size=9)
widths(wa, [58, 12, 80])

# ===================================================================== Product_Analysis
wp = wb.create_sheet("Product_Analysis")
title(wp, "Product-level Profitability", "All figures are SUMIFS formulas on the Data sheet. Sorted by gross profit (static order).")
ph = ["Division", "Product", "Factory", "Sales", "Cost", "Gross Profit", "Units", "Profit per Unit", "Avg Price / Unit",
      "Cost / Unit", "Gross Margin %", "Revenue Contribution %", "Profit Contribution %", "Rank by Profit",
      "Rank by Margin", "Segment", "Risk Flag", "Recommended Action"]
header(wp, 4, ph)
first, last = 5, 4 + len(P)
for i, r in enumerate(P.itertuples(index=False), start=first):
    wp[f"A{i}"], wp[f"B{i}"], wp[f"C{i}"] = r.Division, r._1, r.Factory
    wp[f"D{i}"] = f"=SUMIFS({R_SALES},{R_PROD},$B{i})"
    wp[f"E{i}"] = f"=SUMIFS({R_COST},{R_PROD},$B{i})"
    wp[f"F{i}"] = f"=SUMIFS({R_GP},{R_PROD},$B{i})"
    wp[f"G{i}"] = f"=SUMIFS({R_UNITS},{R_PROD},$B{i})"
    wp[f"H{i}"] = f"=IFERROR(F{i}/G{i},0)"
    wp[f"I{i}"] = f"=IFERROR(D{i}/G{i},0)"
    wp[f"J{i}"] = f"=IFERROR(E{i}/G{i},0)"
    wp[f"K{i}"] = f"=IFERROR(F{i}/D{i},0)"
    wp[f"L{i}"] = f"=IFERROR(D{i}/$D$22,0)"
    wp[f"M{i}"] = f"=IFERROR(F{i}/$F$22,0)"
    wp[f"N{i}"] = f"=RANK(F{i},$F${first}:$F${last})"
    wp[f"O{i}"] = f"=RANK(K{i},$K${first}:$K${last})"
    wp[f"P{i}"] = (f'=IF(L{i}>=Assumptions!$B$8,IF(K{i}>=Assumptions!$B$5,"Star","Volume trap"),'
                   f'IF(K{i}>=Assumptions!$B$5,"Niche premium","Under-performer"))')
    wp[f"Q{i}"] = (f'=IF(K{i}<Assumptions!$B$7,"Critical",IF(K{i}<Assumptions!$B$6,"High",'
                   f'IF(K{i}<Assumptions!$B$5,"Watch","Healthy")))')
    wp[f"R{i}"] = (f'=IF(Q{i}="Critical","Reprice + renegotiate cost; discontinuation review if no uplift",'
                   f'IF(Q{i}="High","Cost renegotiation / modest price increase",'
                   f'IF(Q{i}="Watch","Monitor; test small price or sourcing improvement",'
                   f'IF(L{i}>=Assumptions!$B$8,"Protect and grow","Maintain; cross-sell"))))')
tr = 22
wp[f"A{tr}"] = "TOTAL / PORTFOLIO"
for col in "DEFG":
    wp[f"{col}{tr}"] = f"=SUM({col}{first}:{col}{last})"
wp[f"H{tr}"] = f"=F{tr}/G{tr}"; wp[f"I{tr}"] = f"=D{tr}/G{tr}"; wp[f"J{tr}"] = f"=E{tr}/G{tr}"
wp[f"K{tr}"] = f"=F{tr}/D{tr}"
wp[f"L{tr}"] = f"=SUM(L{first}:L{last})"; wp[f"M{tr}"] = f"=SUM(M{first}:M{last})"
wp["A23"] = "Check: Sales total vs Data sheet (should be 0)"; wp["D23"] = f"=ROUND(D{tr}-SUM({R_SALES}),2)"
for r in range(first, tr + 2):
    for c in range(1, 19):
        cell = wp.cell(row=r, column=c); cell.font = bold if r == tr else base
        if r <= last or r == tr:
            cell.border = box
    for col, fmt in [("D", USD), ("E", USD), ("F", USD), ("G", INT), ("H", USD2), ("I", USD2), ("J", USD2),
                     ("K", PCT), ("L", PCT), ("M", PCT)]:
        wp[f"{col}{r}"].number_format = fmt
for c in range(1, 19):
    wp.cell(row=tr, column=c).fill = PatternFill("solid", fgColor=CREAM)
red, amber, yel, grn = [PatternFill("solid", fgColor=x) for x in ("F4B6BD", "F9D9A8", "FFF2B3", "BFE5DF")]
wp.conditional_formatting.add(f"Q{first}:Q{last}", CellIsRule(operator="equal", formula=['"Critical"'], fill=red))
wp.conditional_formatting.add(f"Q{first}:Q{last}", CellIsRule(operator="equal", formula=['"High"'], fill=amber))
wp.conditional_formatting.add(f"Q{first}:Q{last}", CellIsRule(operator="equal", formula=['"Watch"'], fill=yel))
wp.conditional_formatting.add(f"Q{first}:Q{last}", CellIsRule(operator="equal", formula=['"Healthy"'], fill=grn))
widths(wp, [11, 34, 17, 11, 11, 12, 9, 10, 10, 10, 11, 12, 12, 8, 8, 16, 10, 62])
wp.freeze_panes = "C5"

# ===================================================================== Division_Analysis
wv = wb.create_sheet("Division_Analysis")
title(wv, "Division Performance", "Revenue vs profit imbalance and margin efficiency by division.")
header(wv, 4, ["Division", "Sales", "Cost", "Gross Profit", "Units", "Gross Margin %", "Profit per Unit",
               "Revenue Share %", "Profit Share %", "Profit - Revenue Gap (pp)", "Products", "Avg Product Margin % (simple)", "Verdict"])
divs = list(a.division_metrics(df)["Division"])
for i, d in enumerate(divs, start=5):
    wv[f"A{i}"] = d
    wv[f"B{i}"] = f"=SUMIFS({R_SALES},{R_DIV},$A{i})"
    wv[f"C{i}"] = f"=SUMIFS({R_COST},{R_DIV},$A{i})"
    wv[f"D{i}"] = f"=SUMIFS({R_GP},{R_DIV},$A{i})"
    wv[f"E{i}"] = f"=SUMIFS({R_UNITS},{R_DIV},$A{i})"
    wv[f"F{i}"] = f"=IFERROR(D{i}/B{i},0)"
    wv[f"G{i}"] = f"=IFERROR(D{i}/E{i},0)"
    wv[f"H{i}"] = f"=B{i}/$B$8"
    wv[f"I{i}"] = f"=D{i}/$D$8"
    wv[f"J{i}"] = f"=(I{i}-H{i})*100"
    wv[f"K{i}"] = f"=COUNTIFS(Product_Analysis!$A${first}:$A${last},$A{i})"
    wv[f"L{i}"] = f"=AVERAGEIFS(Product_Analysis!$K${first}:$K${last},Product_Analysis!$A${first}:$A${last},$A{i})"
    wv[f"M{i}"] = f'=IF(F{i}<Assumptions!$B$5-0.1,"Structural margin issue",IF(J{i}>0.5,"Efficient - profit share exceeds revenue share","In line"))'
wv["A8"] = "TOTAL"
for col in "BCDE":
    wv[f"{col}8"] = f"=SUM({col}5:{col}7)"
wv["F8"] = "=D8/B8"; wv["G8"] = "=D8/E8"; wv["H8"] = "=SUM(H5:H7)"; wv["I8"] = "=SUM(I5:I7)"
for r in range(5, 9):
    for c in range(1, 14):
        cell = wv.cell(row=r, column=c); cell.font = bold if r == 8 else base; cell.border = box
    for col, fmt in [("B", USD), ("C", USD), ("D", USD), ("E", INT), ("F", PCT), ("G", USD2), ("H", PCT), ("I", PCT),
                     ("J", '0.0;-0.0;0.0'), ("L", PCT)]:
        wv[f"{col}{r}"].number_format = fmt
widths(wv, [14, 12, 12, 13, 9, 12, 11, 12, 12, 14, 9, 16, 44])
ch = BarChart(); ch.type = "col"; ch.title = "Revenue vs gross profit by division"; ch.style = 10
ch.add_data(Reference(wv, min_col=2, min_row=4, max_row=7), titles_from_data=True)
ch.add_data(Reference(wv, min_col=4, min_row=4, max_row=7), titles_from_data=True)
ch.set_categories(Reference(wv, min_col=1, min_row=5, max_row=7))
ch.series[0].graphicalProperties.solidFill = "BCAAA4"; ch.series[1].graphicalProperties.solidFill = COCOA
ch.y_axis.numFmt = '$#,##0'; ch.height, ch.width = 8, 15
ch.roundedCorners = False; ch.x_axis.delete = False; ch.y_axis.delete = False
ch.legend.overlay = False; ch.title.overlay = False
wv.add_chart(ch, "A11")
ch2 = BarChart(); ch2.type = "col"; ch2.title = "Gross margin % by division"; ch2.style = 10
ch2.add_data(Reference(wv, min_col=6, min_row=4, max_row=7), titles_from_data=True)
ch2.set_categories(Reference(wv, min_col=1, min_row=5, max_row=7))
ch2.series[0].graphicalProperties.solidFill = CARAMEL; ch2.y_axis.numFmt = '0%'; ch2.height, ch2.width = 8, 12
ch2.roundedCorners = False; ch2.x_axis.delete = False; ch2.y_axis.delete = False
ch2.legend = None; ch2.title.overlay = False
wv.add_chart(ch2, "H11")

# ===================================================================== Pareto
wr = wb.create_sheet("Pareto")
title(wr, "Profit Concentration (Pareto)", "Products ranked by gross profit; cumulative share of profit and of revenue.")
header(wr, 4, ["Rank", "Product", "Gross Profit", "Profit Share %", "Cumulative Profit %", "Sales", "Revenue Share %",
               "Cumulative Revenue %", "In top 80% of profit?", "Cumulative % of products"])
order_p = list(P.sort_values("Gross Profit", ascending=False)["Product Name"])
for i, n in enumerate(order_p, start=5):
    k = i - 4
    wr[f"A{i}"] = k; wr[f"B{i}"] = n
    wr[f"C{i}"] = f"=INDEX(Product_Analysis!$F${first}:$F${last},MATCH($B{i},Product_Analysis!$B${first}:$B${last},0))"
    wr[f"D{i}"] = f"=C{i}/SUM($C$5:$C$19)"
    wr[f"E{i}"] = f"=SUM($D$5:D{i})"
    wr[f"F{i}"] = f"=INDEX(Product_Analysis!$D${first}:$D${last},MATCH($B{i},Product_Analysis!$B${first}:$B${last},0))"
    wr[f"G{i}"] = f"=F{i}/SUM($F$5:$F$19)"
    wr[f"H{i}"] = f"=SUM($G$5:G{i})"
    wr[f"I{i}"] = f'=IF(E{i}-D{i}<Assumptions!$B$9,"Yes","No")'
    wr[f"J{i}"] = f"=A{i}/COUNT($A$5:$A$19)"
for r in range(5, 20):
    for c in range(1, 11):
        wr.cell(row=r, column=c).font = base; wr.cell(row=r, column=c).border = box
    for col, fmt in [("C", USD), ("D", PCT), ("E", PCT), ("F", USD), ("G", PCT), ("H", PCT), ("J", PCT)]:
        wr[f"{col}{r}"].number_format = fmt
wr["A21"] = "Products needed for 80% of profit"; wr["E21"] = '=COUNTIF(I5:I19,"Yes")'
wr["A22"] = "Products needed for 80% of revenue"; wr["E22"] = "=COUNTIF(H5:H19,\"<\"&Assumptions!$B$9)+1"
wr["A23"] = "Top-5 products' profit share"; wr["E23"] = "=E9"; wr["E23"].number_format = PCT
wr["A24"] = "Top-1 product's profit share"; wr["E24"] = "=D5"; wr["E24"].number_format = PCT
wr["A25"] = "Profit HHI (0-10,000; >2,500 = highly concentrated)"; wr["E25"] = "=SUMPRODUCT((D5:D19*100)^2)"; wr["E25"].number_format = "#,##0"
for r in range(21, 26):
    wr[f"A{r}"].font = bold; wr[f"E{r}"].font = bold
widths(wr, [7, 34, 13, 12, 14, 12, 13, 14, 14, 14])
bc = BarChart(); bc.type = "col"; bc.title = "Pareto - gross profit by product"; bc.style = 10
bc.add_data(Reference(wr, min_col=3, min_row=4, max_row=19), titles_from_data=True)
bc.set_categories(Reference(wr, min_col=2, min_row=5, max_row=19))
bc.series[0].graphicalProperties.solidFill = COCOA; bc.y_axis.numFmt = '$#,##0'
lc = LineChart(); lc.add_data(Reference(wr, min_col=5, min_row=4, max_row=19), titles_from_data=True)
lc.y_axis.axId = 200; lc.y_axis.numFmt = '0%'; lc.y_axis.crosses = "max"; lc.y_axis.scaling.max = 1; lc.y_axis.scaling.min = 0
lc.series[0].graphicalProperties.line.solidFill = BERRY; lc.y_axis.delete = False
bc.x_axis.delete = False; bc.y_axis.delete = False; bc.roundedCorners = False
bc.legend.overlay = False; bc.title.overlay = False
bc += lc; bc.height, bc.width = 9.5, 20
wr.add_chart(bc, "A28")

# ===================================================================== Cost_Diagnostics
wc = wb.create_sheet("Cost_Diagnostics")
title(wc, "Cost Structure Diagnostics & Repricing Scenarios", "Cost-vs-sales scatter, risk flags and what price/cost would restore a target margin.")
wc["A3"] = "Target gross margin for scenarios"; wc["A3"].font = bold
wc["D3"] = 0.50; wc["D3"].font, wc["D3"].fill, wc["D3"].number_format = inp, inp_fill, PCT
header(wc, 5, ["Product", "Sales", "Cost", "Gross Margin %", "Cost Ratio %", "Risk Flag", "Price / Unit", "Cost / Unit",
               "Required price for target GM", "Price increase needed %", "OR max cost / unit for target GM", "Cost cut needed %",
               "Profit uplift if repriced (constant units)"])
for i in range(first, last + 1):
    r = i + 1  # rows 6..20
    wc[f"A{r}"] = f"=Product_Analysis!B{i}"
    wc[f"B{r}"] = f"=Product_Analysis!D{i}"; wc[f"C{r}"] = f"=Product_Analysis!E{i}"
    wc[f"D{r}"] = f"=Product_Analysis!K{i}"; wc[f"E{r}"] = f"=IFERROR(C{r}/B{r},0)"
    wc[f"F{r}"] = f"=Product_Analysis!Q{i}"
    wc[f"G{r}"] = f"=Product_Analysis!I{i}"; wc[f"H{r}"] = f"=Product_Analysis!J{i}"
    wc[f"I{r}"] = f"=IF(D{r}>=$D$3,G{r},H{r}/(1-$D$3))"
    wc[f"J{r}"] = f"=IFERROR(I{r}/G{r}-1,0)"
    wc[f"K{r}"] = f"=IF(D{r}>=$D$3,H{r},G{r}*(1-$D$3))"
    wc[f"L{r}"] = f"=IFERROR(1-K{r}/H{r},0)"
    wc[f"M{r}"] = f"=(I{r}-G{r})*Product_Analysis!G{i}"
    for c in range(1, 14):
        wc.cell(row=r, column=c).font = base; wc.cell(row=r, column=c).border = box
    for col, fmt in [("B", USD), ("C", USD), ("D", PCT), ("E", PCT), ("G", USD2), ("H", USD2), ("I", USD2), ("J", PCT), ("K", USD2), ("L", PCT), ("M", USD)]:
        wc[f"{col}{r}"].number_format = fmt
wc["A22"] = "Total profit uplift available (all below-target products, constant units)"; wc["A22"].font = bold
wc["M22"] = "=SUM(M6:M20)"; wc["M22"].number_format = USD; wc["M22"].font = bold
wc["A23"] = "...as % of current portfolio gross profit"; wc["M23"] = "=M22/Product_Analysis!F22"; wc["M23"].number_format = '0.0%'
wc["A24"] = "Note: scenarios hold units constant; real demand may fall after a price rise. Cost-cut column is the alternative lever."
wc["A24"].font = Font(name=FONT, size=9, italic=True, color="666666")
for rng_, fl in [("F6:F20", None)]:
    wc.conditional_formatting.add(rng_, CellIsRule(operator="equal", formula=['"Critical"'], fill=red))
    wc.conditional_formatting.add(rng_, CellIsRule(operator="equal", formula=['"High"'], fill=amber))
    wc.conditional_formatting.add(rng_, CellIsRule(operator="equal", formula=['"Watch"'], fill=yel))
    wc.conditional_formatting.add(rng_, CellIsRule(operator="equal", formula=['"Healthy"'], fill=grn))
widths(wc, [34, 11, 11, 11, 11, 10, 10, 10, 14, 13, 16, 12, 16])
sc = ScatterChart(); sc.title = "Cost vs sales by product"; sc.style = 13
sc.x_axis.title = "Sales ($)"; sc.y_axis.title = "Cost ($)"
s = Series(Reference(wc, min_col=3, min_row=6, max_row=20), Reference(wc, min_col=2, min_row=6, max_row=20), title="Products")
s.marker.symbol = "circle"; s.marker.size = 8; s.marker.graphicalProperties.solidFill = COCOA; s.graphicalProperties.line.noFill = True
sc.series.append(s)
sc.x_axis.scaling.logBase = 10; sc.y_axis.scaling.logBase = 10
sc.x_axis.numFmt = '$#,##0'; sc.y_axis.numFmt = '$#,##0'
sc.x_axis.delete = False; sc.y_axis.delete = False; sc.roundedCorners = False
sc.legend = None; sc.title.overlay = False; sc.x_axis.title.overlay = False; sc.y_axis.title.overlay = False
sc.height, sc.width = 9.5, 18
wc.add_chart(sc, "A27")
wc.freeze_panes = "B6"

# ===================================================================== Monthly
wm = wb.create_sheet("Monthly_Trend")
title(wm, "Monthly Trend & Margin Volatility", "Sales, profit and margin by month (SUMIFS on the Data sheet).")
header(wm, 4, ["Month", "Sales", "Gross Profit", "Gross Margin %", "Chocolate GM %", "Other GM %", "Sugar GM %"])
months = sorted(df["Month"].unique())
for i, m in enumerate(months, start=5):
    wm[f"A{i}"] = pd.Timestamp(m).to_pydatetime(); wm[f"A{i}"].number_format = "mmm-yy"
    wm[f"B{i}"] = f"=SUMIFS({R_SALES},{R_MONTH},$A{i})"
    wm[f"C{i}"] = f"=SUMIFS({R_GP},{R_MONTH},$A{i})"
    wm[f"D{i}"] = f"=IFERROR(C{i}/B{i},0)"
    for col, dv in zip("EFG", ["Chocolate", "Other", "Sugar"]):
        wm[f"{col}{i}"] = f'=IFERROR(SUMIFS({R_GP},{R_MONTH},$A{i},{R_DIV},"{dv}")/SUMIFS({R_SALES},{R_MONTH},$A{i},{R_DIV},"{dv}"),"")'
    for c in range(1, 8):
        wm.cell(row=i, column=c).font = base; wm.cell(row=i, column=c).border = box
    wm[f"B{i}"].number_format = wm[f"C{i}"].number_format = USD
    for col in "DEFG":
        wm[f"{col}{i}"].number_format = PCT
lr = 4 + len(months)
wm[f"A{lr+2}"] = "Margin volatility (std dev of monthly GM, pp)"; wm[f"A{lr+2}"].font = bold
for col in "DEFG":
    wm[f"{col}{lr+2}"] = f"=STDEV({col}5:{col}{lr})*100"; wm[f"{col}{lr+2}"].number_format = "0.00"; wm[f"{col}{lr+2}"].font = bold
wm[f"A{lr+3}"] = "Note: months with no sales for a division are left blank and excluded. Sugar and Other volatility is driven by tiny monthly volumes (product mix), not by price or cost changes."
wm[f"A{lr+3}"].font = Font(name=FONT, size=9, italic=True, color="666666")
widths(wm, [12, 12, 13, 13, 14, 12, 12])
lc2 = LineChart(); lc2.title = "Monthly gross margin %"; lc2.style = 12
lc2.add_data(Reference(wm, min_col=4, min_row=4, max_row=lr), titles_from_data=True)
lc2.set_categories(Reference(wm, min_col=1, min_row=5, max_row=lr))
lc2.y_axis.numFmt = '0%'; lc2.y_axis.scaling.min = 0.5; lc2.y_axis.scaling.max = 0.8; lc2.x_axis.number_format = "mmm-yy"
lc2.x_axis.delete = False; lc2.y_axis.delete = False; lc2.roundedCorners = False
lc2.legend = None; lc2.title.overlay = False; lc2.height, lc2.width = 8, 18
wm.add_chart(lc2, "I4")

# ===================================================================== Factory
wf = wb.create_sheet("Factory_Analysis")
title(wf, "Factory Profitability", "Products mapped to factories using the table in the project brief.")
header(wf, 4, ["Factory", "Sales", "Cost", "Gross Profit", "Gross Margin %", "Profit Share %", "Cost Ratio %", "Latitude", "Longitude"])
Fm = a.factory_metrics(df)
for i, r in enumerate(Fm.itertuples(index=False), start=5):
    wf[f"A{i}"] = r.Factory
    wf[f"B{i}"] = f"=SUMIFS({R_SALES},{R_FACT},$A{i})"; wf[f"C{i}"] = f"=SUMIFS({R_COST},{R_FACT},$A{i})"
    wf[f"D{i}"] = f"=SUMIFS({R_GP},{R_FACT},$A{i})"; wf[f"E{i}"] = f"=IFERROR(D{i}/B{i},0)"
    wf[f"F{i}"] = f"=D{i}/SUM($D$5:$D$9)"; wf[f"G{i}"] = f"=IFERROR(C{i}/B{i},0)"
    wf[f"H{i}"], wf[f"I{i}"] = r.Lat, r.Lon
    for c in range(1, 10):
        wf.cell(row=i, column=c).font = base; wf.cell(row=i, column=c).border = box
    wf[f"B{i}"].number_format = wf[f"C{i}"].number_format = wf[f"D{i}"].number_format = USD
    for col in "EFG":
        wf[f"{col}{i}"].number_format = PCT
wf["A11"] = "Top-2 factories' profit share"; wf["D11"] = "=F5+F6"; wf["D11"].number_format = PCT
wf["A11"].font = wf["D11"].font = bold
widths(wf, [20, 12, 12, 13, 13, 12, 12, 11, 11])
fc = BarChart(); fc.type = "bar"; fc.title = "Gross profit by factory"; fc.style = 10
fc.add_data(Reference(wf, min_col=4, min_row=4, max_row=9), titles_from_data=True)
fc.set_categories(Reference(wf, min_col=1, min_row=5, max_row=9))
fc.series[0].graphicalProperties.solidFill = "264653"; fc.y_axis.numFmt = '$#,##0'
fc.x_axis.delete = False; fc.y_axis.delete = False; fc.roundedCorners = False
fc.legend = None; fc.title.overlay = False; fc.height, fc.width = 8, 15
wf.add_chart(fc, "A14")

# ===================================================================== Dashboard
wdsh = wb.create_sheet("Dashboard", 0)
title(wdsh, "Nassau Candy Distributor - Product Profitability Dashboard",
      f"Orders {df['Order Date'].min():%d %b %Y} - {df['Order Date'].max():%d %b %Y} | all KPIs are live formulas")
kp = [("Total Sales", f"=Product_Analysis!D22", USD), ("Gross Profit", "=Product_Analysis!F22", USD),
      ("Gross Margin %", "=Product_Analysis!K22", PCT), ("Profit per Unit", "=Product_Analysis!H22", USD2),
      ("Units Sold", "=Product_Analysis!G22", INT), ("Products at risk (Critical/High)", '=COUNTIF(Product_Analysis!Q5:Q19,"Critical")+COUNTIF(Product_Analysis!Q5:Q19,"High")', INT),
      ("Products for 80% of profit", "=Pareto!E21", INT), ("Top-5 profit share", "=Pareto!E23", PCT)]
for i, (lab, f, fmt) in enumerate(kp):
    col = 1 + (i % 4) * 3
    row = 4 if i < 4 else 8
    wdsh.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col + 1)
    wdsh.merge_cells(start_row=row + 1, start_column=col, end_row=row + 1, end_column=col + 1)
    c = wdsh.cell(row=row, column=col, value=lab); c.font = Font(name=FONT, size=9, bold=True, color="FFFFFF")
    c.fill = PatternFill("solid", fgColor=COCOA); c.alignment = Alignment(horizontal="center")
    wdsh.cell(row=row, column=col + 1).fill = PatternFill("solid", fgColor=COCOA)
    v = wdsh.cell(row=row + 1, column=col, value=f); v.number_format = fmt
    v.font = Font(name=FONT, size=18, bold=True, color=COCOA); v.alignment = Alignment(horizontal="center")
    v.fill = PatternFill("solid", fgColor=CREAM); wdsh.cell(row=row + 1, column=col + 1).fill = PatternFill("solid", fgColor=CREAM)
    wdsh.row_dimensions[row + 1].height = 30
for col in range(1, 13):
    wdsh.column_dimensions[L(col)].width = 13
wdsh["A12"] = "Key messages"; wdsh["A12"].font = Font(name=FONT, size=11, bold=True, color=COCOA)
msgs = [
    '="Five Wonka Bars generate "&TEXT(Pareto!E23,"0.0%")&" of gross profit - the portfolio is highly concentrated."',
    '="Kazookles earns only "&TEXT(INDEX(Product_Analysis!K5:K19,MATCH("Kazookles",Product_Analysis!B5:B19,0)),"0.0%")&" gross margin vs "&TEXT(Product_Analysis!K22,"0.0%")&" portfolio average."',
    '="Division \'Other\' margin ("&TEXT(Division_Analysis!F6,"0.0%")&") trails Chocolate ("&TEXT(Division_Analysis!F5,"0.0%")&"); its profit share is below its revenue share."',
    '="Repricing all below-target products to "&TEXT(Cost_Diagnostics!D3,"0%")&" margin would add about "&TEXT(Cost_Diagnostics!M22,"$#,##0")&" gross profit at constant volume."',
]
for i, m in enumerate(msgs, start=13):
    wdsh[f"A{i}"] = m; wdsh[f"A{i}"].font = base
bp = BarChart(); bp.type = "bar"; bp.title = "Gross profit by product"; bp.style = 10
bp.add_data(Reference(wp, min_col=6, min_row=4, max_row=last), titles_from_data=True)
bp.set_categories(Reference(wp, min_col=2, min_row=5, max_row=last))
bp.series[0].graphicalProperties.solidFill = COCOA; bp.y_axis.numFmt = '$#,##0'
bp.x_axis.scaling.orientation = "maxMin"; bp.x_axis.delete = False; bp.y_axis.delete = False
bp.roundedCorners = False; bp.legend = None; bp.title.overlay = False; bp.height, bp.width = 10, 17
wdsh.add_chart(bp, "A18")
bm = BarChart(); bm.type = "bar"; bm.title = "Gross margin % by product"; bm.style = 10
bm.add_data(Reference(wp, min_col=11, min_row=4, max_row=last), titles_from_data=True)
bm.set_categories(Reference(wp, min_col=2, min_row=5, max_row=last))
bm.series[0].graphicalProperties.solidFill = CARAMEL; bm.y_axis.numFmt = '0%'; bm.y_axis.scaling.min = 0; bm.y_axis.scaling.max = 1
bm.x_axis.scaling.orientation = "maxMin"; bm.x_axis.delete = False; bm.y_axis.delete = False
bm.roundedCorners = False; bm.legend = None; bm.title.overlay = False; bm.height, bm.width = 10, 15
wdsh.add_chart(bm, "H18")

wb._sheets = [wb[n] for n in ["Dashboard", "Product_Analysis", "Division_Analysis", "Pareto", "Cost_Diagnostics",
                              "Monthly_Trend", "Factory_Analysis", "Assumptions", "Data"]]
for ws in wb.worksheets:
    ws.sheet_properties.tabColor = COCOA if ws.title in ("Dashboard", "Assumptions") else CARAMEL
wb.active = 0
out_path = ROOT / "Nassau_Candy_Profitability_Analysis.xlsx"
wb.save(out_path)
print("saved", out_path)
