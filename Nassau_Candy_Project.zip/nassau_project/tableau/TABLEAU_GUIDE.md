# Tableau build guide - Nassau Candy Profitability

Tableau workbooks (.twbx) can only be authored inside Tableau, so this folder gives you
clean, Tableau-ready data and an exact recipe. Build time is about 45 minutes in Tableau Public or Desktop.

## 1. Connect the data
Connect to **01_orders_clean.csv** (fact table, 10,194 rows). Optionally add the other CSVs as separate data sources:

| File | Use |
|---|---|
| 01_orders_clean.csv | All order-level charts and filters |
| 02_product_metrics.csv | Product scorecard, segment and risk flag (pre-computed) |
| 03_division_metrics.csv | Division revenue vs profit share |
| 04_pareto_products.csv | Pareto chart (cumulative % already calculated) |
| 05_monthly_trend.csv / 06_monthly_by_division.csv | Trend lines |
| 07_factory_metrics.csv | Factory map (Lat / Lon included) |
| 08_state_metrics.csv | State concentration |
| 09_repricing_scenarios.csv | Repricing table |

In Data Source: set **Order Date** to Date. Margin columns are stored as fractions, so set the default number format of
`Gross Margin %`, `Revenue Contribution %`, `Profit Contribution %`, `Cost Ratio %` to Percentage (1 decimal).

## 2. Calculated fields (on 01_orders_clean)
```
Gross Margin %          = SUM([Gross Profit]) / SUM([Sales])
Profit per Unit         = SUM([Gross Profit]) / SUM([Units])
Cost Ratio              = SUM([Cost]) / SUM([Sales])
Revenue Contribution    = SUM([Sales]) / TOTAL(SUM([Sales]))
Profit Contribution     = SUM([Gross Profit]) / TOTAL(SUM([Gross Profit]))
Portfolio Margin        = { FIXED : SUM([Gross Profit]) / SUM([Sales]) }
Margin Gap (pp)         = [Gross Margin %] - [Portfolio Margin]

Risk Flag =
IF [Gross Margin %] < 0.25 THEN "Critical"
ELSEIF [Gross Margin %] < 0.50 THEN "High"
ELSEIF [Gross Margin %] < [Margin Threshold] THEN "Watch"
ELSE "Healthy" END

Segment =
IF [Revenue Contribution] >= 1/15 AND [Gross Margin %] >= [Margin Threshold] THEN "Star"
ELSEIF [Revenue Contribution] >= 1/15 THEN "Volume trap"
ELSEIF [Gross Margin %] >= [Margin Threshold] THEN "Niche premium"
ELSE "Under-performer" END
```
Create a **Parameter** `Margin Threshold` (Float, 0 - 0.9, step 0.01, default 0.659) and show it as a slider.

Pareto (table calcs on the product-level sheet, sort Product desc by SUM(Gross Profit)):
```
Cumulative Profit %     = RUNNING_SUM(SUM([Gross Profit])) / TOTAL(SUM([Gross Profit]))
```
(or use 04_pareto_products.csv and plot `Cumulative %` directly).

Required price for target margin (parameter `Target GM`, default 0.50):
```
Required Price = (SUM([Cost]) / SUM([Units])) / (1 - [Target GM])
Price Increase % = [Required Price] / (SUM([Sales]) / SUM([Units])) - 1
```

## 3. Worksheets
1. **Product Leaderboard** - Rows: Product Name (sort by SUM Gross Profit desc); Columns: SUM(Gross Profit); Color: Risk Flag; Label: Gross Margin %.
2. **Margin Ranking** - same rows, Columns: Gross Margin %; add a reference line at `Margin Threshold`.
3. **Profit Contribution** - Donut/treemap: Size = SUM(Gross Profit), Color = Division, Label = Profit Contribution.
4. **Portfolio Map** - Columns: Revenue Contribution (log axis), Rows: Gross Margin %, Size: SUM(Gross Profit), Color: Segment, Detail: Product Name. Reference lines: Portfolio Margin and 1/15.
5. **Division Revenue vs Profit** - Rows: Division; Columns: Measure Values = SUM(Sales), SUM(Gross Profit) (side-by-side bars).
6. **Division Margin** - bar of Gross Margin % by Division with Portfolio Margin reference line; box plot of margin by Product within Division.
7. **Cost vs Sales** - Columns: SUM(Sales), Rows: SUM(Cost), Detail: Product Name, Color: Risk Flag, both axes log. Add trend/reference lines (Analytics > Reference line, constant per cell = 0.75 x, 0.5 x, 0.341 x) or simply show the 25% / 50% bands as shaded distribution bands.
8. **Pareto** - dual axis: bars = SUM(Gross Profit); line = Cumulative Profit %; reference line at 80%.
9. **Monthly Trend** - Columns: MONTH(Order Date); Rows: Gross Margin %; Color: Division.
10. **Factory Map** - use 07_factory_metrics.csv: Lat/Lon as Latitude/Longitude, Size = Gross Profit, Color = Gross Margin %.
11. **Repricing Table** - from 09_repricing_scenarios.csv.

## 4. Dashboards (1400 x 900, Automatic for Tableau Public)
- **Dashboard 1 - Product Profitability**: KPI strip (Sales, Gross Profit, Gross Margin %, Profit per Unit) on top, Leaderboard + Margin Ranking + Portfolio Map.
- **Dashboard 2 - Division & Factory**: Division revenue vs profit, margin, factory map, monthly trend.
- **Dashboard 3 - Cost & Risk**: Cost vs Sales scatter, risk-flag table, repricing table.
- **Dashboard 4 - Concentration**: Pareto + dependency KPIs (Top-5 profit share, products for 80% of profit).

Filters (apply to all worksheets, "Show Filter"): Order Date (range), Division, Region, Product Name (wildcard match = product search),
and the `Margin Threshold` parameter. Use dashboard actions: click a product in the leaderboard to filter every other chart.

Palette: cocoa #3E2723, caramel #E09F3E, berry #C8283C, mint #2A9D8F, navy #264653.

## 5. Expected checks (your numbers should match)
Sales $141,783.63 | Gross profit $93,442.80 | Gross margin 65.9% | Units 38,654 | Kazookles margin 7.7% | Top-5 products = 95.1% of profit.
